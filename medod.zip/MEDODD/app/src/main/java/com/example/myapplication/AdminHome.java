package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class AdminHome extends AppCompatActivity {
    //binding the image view to add the data
    private ImageView msk,san,therm,ww,firstaid;
    private ImageView bp,sg,ne,in,ay,he,me,ba,di,nu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        //binding
        msk = (ImageView)findViewById(R.id.mask);
        san = (ImageView)findViewById(R.id.sani);
        therm = (ImageView)findViewById(R.id.thermo);
        ww = (ImageView)findViewById(R.id.wet);
        firstaid = (ImageView)findViewById(R.id.fa);
        nu = (ImageView)findViewById(R.id.nu);
        di = (ImageView)findViewById(R.id.dia);
        ba = (ImageView)findViewById(R.id.babyad);
        me = (ImageView)findViewById(R.id.me);
        he = (ImageView)findViewById(R.id.herbal);
        ay = (ImageView)findViewById(R.id.ay);
        bp = (ImageView)findViewById(R.id.bpmachine);
        sg = (ImageView)findViewById(R.id.bloodglu);
        ne = (ImageView)findViewById(R.id.nebul);
        in = (ImageView)findViewById(R.id.inhal);
        //on click go to add the additem activity with the intent of category which datait is
        msk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Mask");
                startActivity(in);
            }
        });
        san.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Sanitizer");
                startActivity(in);
            }
        });
        therm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Thermometer");
                startActivity(in);
            }
        });
        ww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Wet Wipes");
                startActivity(in);
            }
        });
        firstaid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","First Aid");
                startActivity(in);
            }
        });

        ne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Nebulizer");
                startActivity(in);
            }
        });
        in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Inhaler");
                startActivity(in);
            }
        });
        sg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Blood Glucose");
                startActivity(in);
            }
        });
        bp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","sphygmomanometer");
                startActivity(in);
            }
        });
        nu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Nutrition Care");
                startActivity(in);
            }
        });
        di.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Diabetes Care");
                startActivity(in);
            }
        });
        ba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Baby & Mom Care");
                startActivity(in);
            }
        });
        me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Medicine");
                startActivity(in);
            }
        });
        he.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Herbal");
                startActivity(in);
            }
        });
        ay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(AdminHome.this,adminadditems.class);
                in.putExtra("category","Ayurveda");
                startActivity(in);
            }
        });
    }
}
