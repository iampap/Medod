package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class adminadditems extends AppCompatActivity {
    //items that r added in database
    private String categoryname ,descr , price , pname , currentdate, currenttime ,itemkey , imgurl;
    private Button add;
    //for product information
    private EditText name,desc,pri;
    private ImageView proimage;
    //for image getting from user and upload in databse
    private static final int gallpic = 1;
    private Uri imguri;
    //database
    private StorageReference prostroref;
    private DatabaseReference dref;
    //progress bar
    private ProgressDialog bar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminadditems);
        //binding
        proimage = (ImageView)findViewById(R.id.imageitem);
        add= (Button)findViewById(R.id.additembuttom);
        name = (EditText)findViewById(R.id.proname);
        desc = (EditText)findViewById(R.id.prodesc);
        pri = (EditText)findViewById(R.id.proprice);
        //progressbar
        bar = new ProgressDialog(this);
        //image click to take from user
        proimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenGallery();
            }
        });
        //after clicking on upload
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validata();
            }
        });
        //category name getting from previous activity from intent and toasting it
        categoryname = getIntent().getExtras().get("category").toString();
        Toast.makeText(getApplicationContext(),categoryname,Toast.LENGTH_LONG).show();
        //database call for upload the image and data in storage and database
        prostroref  = FirebaseStorage.getInstance().getReference().child("Product Images");
        dref = FirebaseDatabase.getInstance().getReference().child("products");
    }
    //validate the data
    private void validata() {
        descr = desc.getText().toString();
        price= pri.getText().toString();
        pname = name.getText().toString();
        if(imguri == null)
        {
            Toast.makeText(getApplicationContext(),"Image required",Toast.LENGTH_LONG).show();
        }
        else if(descr.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Description required",Toast.LENGTH_LONG).show();
        }
        else if(price.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Price Plz!!",Toast.LENGTH_LONG).show();
        }
        else if(pname.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Product Name Plz!!",Toast.LENGTH_LONG).show();
        }
        else{
            storeitemsinformation();
        }
    }
    //adding the image to storage database
    private void storeitemsinformation() {
        bar.setTitle("Adding New Items");
        bar.setMessage("Plz Wait....while we r adding the items!");
        bar.setCanceledOnTouchOutside(false);
        bar.show();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat currdate= new SimpleDateFormat(" dd:MMM:yyyy");
        currentdate = currdate.format(calendar.getTime());
        SimpleDateFormat currtime= new SimpleDateFormat("HH:MM:SS:a");
        currenttime = currtime.format(calendar.getTime());
        itemkey =  currentdate+" "+currenttime;
        final StorageReference filepath = prostroref.child(imguri.getEncodedPath()+":"+itemkey+".jpg");
        final UploadTask uploadTask = filepath.putFile(imguri);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String mess = e.toString();
                Toast.makeText(getApplicationContext(),"Error" + mess,Toast.LENGTH_LONG);
                bar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(getApplicationContext(),"Image Upload Successfully..",Toast.LENGTH_LONG);
                Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw task.getException();
                        }
                        imgurl = filepath.getDownloadUrl().toString();
                        return filepath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            imgurl = task.getResult().toString();
                            Toast.makeText(adminadditems.this,"Get product image",Toast.LENGTH_LONG);
                            saveproinfodatbase();
                        }
                    }
                });
            }
        });
    }
    //adding the items info to the database
    private void saveproinfodatbase() {
        HashMap<String , Object> promap = new HashMap<>();
        promap.put("pid",itemkey);
        promap.put("date",currentdate);
        promap.put("time",currenttime);
        promap.put("description",descr);
        promap.put("image",imgurl);
        promap.put("category",categoryname);
        promap.put("price",price);
        promap.put("proname",pname);
        dref.child(categoryname).child(itemkey).updateChildren(promap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    bar.dismiss();
                    Toast.makeText(adminadditems.this,"Product Added Successfully",Toast.LENGTH_LONG);
                }
                else
                {
                    bar.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    //adding the image from user to display
    private void OpenGallery()
    {
        Intent in = new Intent();
        in.setAction(Intent.ACTION_GET_CONTENT);
        in.setType("image/*");
        startActivityForResult(in,gallpic);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == gallpic && resultCode == RESULT_OK && data!=null)
        {
            imguri = data.getData();
            proimage.setImageURI(imguri);
        }
    }
}
