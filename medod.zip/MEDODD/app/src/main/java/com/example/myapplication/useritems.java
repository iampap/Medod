package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.github.ybq.android.spinkit.style.ThreeBounce;
import com.github.ybq.android.spinkit.style.WanderingCubes;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class useritems extends AppCompatActivity {
    //binding
    private String items;
    private TextView textna,countitm,resfnd;
    private ImageView imcrt,itmbk,srchur;
    //recycler
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    //firebase
    private DatabaseReference proref;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //dialog
    private Dialog dialog,loaderdialog;
    //loader
    private ThreeBounce mCircleDrawable;
    //toast
    private Toast toast;
    //array
    private ArrayList<String> cartitems = new ArrayList<String>();
    private ArrayList<String> productitem = new ArrayList<String>();
    private ArrayList<String> match = new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useritems);
        //binding
        textna = (TextView)findViewById(R.id.itemname);
        imcrt = (ImageView)findViewById(R.id.cartusetitem);
        countitm=findViewById(R.id.itemcount);
        resfnd=findViewById(R.id.resultfound);
        itmbk=findViewById(R.id.itmback);
        srchur=findViewById(R.id.itmsearchpro);
        //getting the intent from the back activity
        items = getIntent().getExtras().get("category").toString();
        textna.setText(items);
        //firebase
        proref = FirebaseDatabase.getInstance().getReference();
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //recycler
        recyclerView = findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //loader
        loader();
        //checkitemincrt
        itemcart();
        //cart
        imcrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fuser != null) {
                    Intent in = new Intent(getApplicationContext(),cart.class);
                    startActivityForResult(in,1);
                }
                else {
                    toast=Toast.makeText(getApplicationContext(),"Login Please3!!, We Insist!!",Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
        itmbk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        srchur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(useritems.this, search.class);
                startActivityForResult(in,1);
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_CANCELED) {
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        }
    }
    private void itemcart() {
            proref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("products").child(items).exists()) {
                            for (DataSnapshot ds : dataSnapshot.child("products").child(items).getChildren()) {
                                String pico = ds.getKey().toString();
                                productitem.add(pico);
                            }
                        }
                        if (fuser != null) {
                        if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                            for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                    child("product").getChildren()) {
                                String crtitm = ds.getKey().toString();
                                cartitems.add(crtitm);
                            }
                        }
                        for (int i = 0; i < productitem.size(); i++) {
                            for (int j = 0; j < cartitems.size(); j++) {
                                if (productitem.get(i).equals(cartitems.get(j))) {
                                    match.add(cartitems.get(j));
                                }
                            }
                        }
                        if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                            if (cartitems.size()>0) {
                                countitm.setText(String.valueOf(cartitems.size()));
                            }
                        }}
                        if (dataSnapshot.child("products").child(items).exists()) {
                            resfnd.setText(String.valueOf(productitem.size())+" Results");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void loader() {
        loaderdialog = new Dialog(useritems.this);
        loaderdialog.setCanceledOnTouchOutside(false);
        loaderdialog.setCancelable(false);
        loaderdialog.setContentView(R.layout.homeaddressdialoge);
        loaderdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView tx = loaderdialog.findViewById(R.id.textshowerror);
        LinearLayout ll=loaderdialog.findViewById(R.id.loaderll);
        ll.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        mCircleDrawable = new ThreeBounce();
        mCircleDrawable.setBounds(0, 0, 100, 100);
        mCircleDrawable.setColor(Color.parseColor("#ffffff"));
        tx.setCompoundDrawables(null, null, mCircleDrawable, null);
        mCircleDrawable.start();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(loaderdialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        loaderdialog.show();
    }

    //load the data on start
    public void onStart() {
        super.onStart();
        proref.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(items).exists()) {
                    FirebaseRecyclerOptions<products> options = new FirebaseRecyclerOptions.Builder<products>().setQuery
                            (proref.child("products").child(items), products.class)
                            .build();
                    FirebaseRecyclerAdapter<products, placeholder> adapter = new FirebaseRecyclerAdapter<products, placeholder>(options) {
                        @Override
                        protected void onBindViewHolder(@NonNull final placeholder placeholder, int i, @NonNull final products products) {
                            placeholder.txtproname.setText(products.getProname());
                            placeholder.textproprice.setText(products.getDisprice() + " Rs/-");
                            placeholder.textprodesc.setText(products.getDescription());
                            placeholder.chk.setVisibility(View.GONE);
                            placeholder.carttx.setVisibility(View.VISIBLE);
                            if(products.getOgprice().equals("0"))
                            {
                                placeholder.txtofprice.setVisibility(View.GONE);
                                placeholder.txtofpercent.setVisibility(View.GONE);
                            }
                            else
                            {
                                double  pri = Integer.parseInt(products.getDisprice());
                                double  off = Integer.parseInt(products.getOgprice());
                                double  diff = off - pri ;
                                int  perof = (int) ((diff / off) * 100);
                                placeholder.txtofpercent.setText(String.valueOf(perof)+"% OFF");
                                placeholder.txtofprice.setText(products.getOgprice()+" Rs/-");
                            }
                            Picasso.get().load(products.getImage()).into(placeholder.proimg);
                            loaderdialog.dismiss();
                            mCircleDrawable.stop();
                            for (int k=0;k<match.size();k++){
                                if(match.get(k).equals(products.getPid()))
                                {
                                    placeholder.chk.setVisibility(View.VISIBLE);
                                    placeholder.carttx.setVisibility(View.GONE);
                                }
                            }
                            //sending the intent to naxt activity
                            placeholder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            /*placeholder.txtofprice.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            placeholder.bnk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            placeholder.txtofpercent.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            placeholder.proimg.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1); }});
                            placeholder.txtproname.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1); }
                            });
                            placeholder.textproprice.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            placeholder.textprodesc.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(useritems.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", items);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });*/
                            //adding to cart
                            placeholder.carttx.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (fuser != null) {
                                        proref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener(){
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if(dataSnapshot.child("Address").exists())
                                                {
                                                    int ct = (int) dataSnapshot.child("Cart List").
                                                            child("product").getChildrenCount();
                                                    if(ct < 8)
                                                    {
                                                    //getting the current date and time
                                                    final String currenttime, currentdate;
                                                    Calendar calfordate = Calendar.getInstance();
                                                    SimpleDateFormat currdate= new SimpleDateFormat("dd:MMM:yyyy");
                                                    currentdate = currdate.format(calfordate.getTime());
                                                    SimpleDateFormat currtime= new SimpleDateFormat("HH:MM:SS:a");
                                                    currenttime = currtime.format(calfordate.getTime());
                                                    //putting the cart info in the database
                                                    final HashMap<String , Object> promap = new HashMap<>();
                                                    promap.put("pid",products.getPid());
                                                    promap.put("disprice",products.getDisprice());
                                                    promap.put("proname",products.getProname());
                                                    promap.put("date",currentdate);
                                                    promap.put("time",currenttime);
                                                    promap.put("quantity","1");
                                                    promap.put("image",products.getImage());
                                                    promap.put("category",items);
                                                    promap.put("ogprice",products.getOgprice());
                                                    //adding the cart detail to admin and the user
                                                    proref.child("User").child(fuser.getUid()).child("Cart List").
                                                            child("product").child(products.getPid()).updateChildren(promap);
                                                    placeholder.chk.setVisibility(View.VISIBLE);
                                                    placeholder.carttx.setVisibility(View.GONE);
                                                        Intent intent = getIntent();
                                                        finish();
                                                        overridePendingTransition(0, 0);
                                                        startActivity(intent);
                                                        overridePendingTransition(0, 0);
                                                    }
                                                    else {
                                                        // custom dialog
                                                        dialog = new Dialog(useritems.this);
                                                        dialog.setContentView(R.layout.homeaddressdialoge);
                                                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                        // set the custom dialog components - text, image and button
                                                        TextView tx = dialog.findViewById(R.id.textshowerror);
                                                        tx.setTextColor(Color.parseColor("#FF0000"));
                                                        tx.setText("Cannot Add More than 8 Items in Cart !!");
                                                        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                        lp.copyFrom(dialog.getWindow().getAttributes());
                                                        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                        lp.gravity = Gravity.CENTER;
                                                        dialog.show();
                                                    }
                                                }
                                                else
                                                {
                                                    // custom dialog
                                                    dialog = new Dialog(useritems.this);
                                                    dialog.setContentView(R.layout.useritemaddressdialoge);
                                                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                    // set the custom dialog components - text, image and button
                                                    TextView tx = dialog.findViewById(R.id.textshowerror);
                                                    TextView add = dialog.findViewById(R.id.addaddressbtn);
                                                    tx.setText("Please Add Address !!");
                                                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                    lp.copyFrom(dialog.getWindow().getAttributes());
                                                    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                    lp.gravity = Gravity.CENTER;
                                                    dialog.getWindow().setAttributes(lp);
                                                    add.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            Intent in = new Intent(useritems.this,address.class);
                                                            startActivity(in);
                                                            dialog.dismiss();
                                                        }
                                                    });
                                                    dialog.show();
                                                }
                                            }
                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                                    }
                                    else {
                                        toast=Toast.makeText(getApplicationContext(),"Login Please!!, We Insist!!",Toast.LENGTH_SHORT);
                                        toast();
                                    }
                                }
                            });
                        }
                        @NonNull
                        @Override
                        public placeholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.useritemproductlayout, parent, false);
                            placeholder holder = new placeholder(view);
                            return holder;
                        }
                    };
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }
                else {
                    toast=Toast.makeText(getApplicationContext(),"Products Not Available in "+items,Toast.LENGTH_SHORT);
                    toast();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}