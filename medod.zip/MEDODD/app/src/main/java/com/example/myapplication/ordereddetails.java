package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

import javax.annotation.Nullable;

public class ordereddetails extends AppCompatActivity {
    //binding
    private String id,totamt,orddt,didt,user,addrid,str,la,cit,stat,pin,odtm,shipp,csb,odsts,pymd;
    private TextView odid,totpr,deldt,usrnm,mono,ordt,street,lm,cy,pc,streetb,lmb,cyb,pcb,cashb,ship,ordsts,paymd,ret,can;
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private FirebaseFirestore db;
    private DocumentReference fs;
    private DatabaseReference dr;
    //Toast
    private Toast toast;
    //dialog
    private Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordereddetails);
        //binding
        odid = findViewById(R.id.orderid);
        totpr = (TextView) findViewById(R.id.totalprice);
        deldt = (TextView) findViewById(R.id.Delidate);
        usrnm = (TextView) findViewById(R.id.usrname);
        mono = (TextView) findViewById(R.id.mobno);
        ordt = (TextView) findViewById(R.id.orderdate);
        street = (TextView) findViewById(R.id.street);
        lm = (TextView) findViewById(R.id.landmarg);
        cy = (TextView) findViewById(R.id.city);
        pc = (TextView) findViewById(R.id.pincode);
        streetb = (TextView) findViewById(R.id.streetbill);
        lmb = (TextView) findViewById(R.id.landmargbill);
        cyb = (TextView) findViewById(R.id.citybill);
        pcb = (TextView) findViewById(R.id.pincodebill);
        cashb = findViewById(R.id.cashback);
        ship = findViewById(R.id.shipping);
        ordsts = findViewById(R.id.orderstatus);
        paymd = findViewById(R.id.payment);
        ret = findViewById(R.id.returnod);
        can = findViewById(R.id.cancelod);
        //recycler
        recyclerView = findViewById(R.id.productrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        dr = FirebaseDatabase.getInstance().getReference();
        //getting intent
        id = getIntent().getExtras().get("orderid").toString();
        odid.setText("Order Id : "+id.toString());
        totamt = getIntent().getExtras().get("total").toString();
        totpr.setText(totamt.toString()+" Rs /-");
        orddt = getIntent().getExtras().get("orderdate").toString();
        odtm=getIntent().getExtras().get("Ordertime").toString();
        ordt.setText("Order Date : "+orddt+" "+odtm);
        didt = getIntent().getExtras().get("diledate").toString();
        deldt.setText(didt);
        addrid=getIntent().getExtras().get("Addreid").toString();
        str=getIntent().getExtras().get("address").toString();
        la=getIntent().getExtras().get("landmarg").toString();
        cit=getIntent().getExtras().get("city").toString();
        stat=getIntent().getExtras().get("state").toString();
        pin=getIntent().getExtras().get("pincode").toString();
        shipp=getIntent().getExtras().get("Shipping").toString();
        csb=getIntent().getExtras().get("Cashback").toString();
        odsts=getIntent().getExtras().get("orderstatus").toString();
        pymd=getIntent().getExtras().get("paymentmode").toString();
        cashb.setText(csb+" Rs /-");
        ship.setText(shipp);
        paymd.setText(pymd);
        //onclick of return and cancel
        ret.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dr.child("User").child(user).child("Orders").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("orderstatus").getValue().toString().equals("Cancelled"))
                        {
                            toast=Toast.makeText(getApplicationContext(),"Order is Cancelled Already!!",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        else{
                            AlertDialog.Builder dialogal = new AlertDialog.Builder(ordereddetails.this);
                            dialogal.setTitle("Are You Sure!!");
                            dialogal.setMessage("Return Order!!");
                            dialogal.setCancelable(false);
                            dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(final DialogInterface dialogal, int which) {
                                    HashMap<String, String> map3  = new HashMap<>();
                                    map3.put("orderstatus","Return");
                                    map3.put("TotalPrice",totamt);
                                    map3.put("Orderid", id);
                                    map3.put("Orderdate",orddt);
                                    map3.put("Ordertime", odtm);
                                    map3.put("DeliveryDate", didt);
                                    map3.put("Street", str);
                                    map3.put("LandMarg", la);
                                    map3.put("City", cit);
                                    map3.put("State", stat);
                                    map3.put("PinCode", pin);
                                    map3.put("Addressid", addrid);
                                    map3.put("Shipping",shipp);
                                    map3.put("Cashback",csb);
                                    map3.put("paymentmode",pymd);
                                    dr.child("User").child(user).child("Orders").child(id).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                dialogal.dismiss();
                                                // Reload current fragment
                                                finish();
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            dialogal.dismiss();
                                            // Reload current fragment
                                            finish();
                                        }
                                    });
                                }
                            });
                            dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alertDialog = dialogal.create();
                            alertDialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        can.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dr.child("User").child(user).child("Orders").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("orderstatus").getValue().toString().equals("Cancelled"))
                        {
                            toast=Toast.makeText(getApplicationContext(),"Order is Cancelled Already!!",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        else{
                            AlertDialog.Builder dialogal = new AlertDialog.Builder(ordereddetails.this);
                            dialogal.setTitle("Are You Sure!!");
                            dialogal.setMessage("Return Order!!");
                            dialogal.setCancelable(false);
                            dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(final DialogInterface dialogal, int which) {
                                    HashMap<String, String> map3  = new HashMap<>();
                                    map3.put("orderstatus","Cancelled");
                                    map3.put("TotalPrice",totamt);
                                    map3.put("Orderid", id);
                                    map3.put("Orderdate",orddt);
                                    map3.put("Ordertime", odtm);
                                    map3.put("DeliveryDate", didt);
                                    map3.put("Street", str);
                                    map3.put("LandMarg", la);
                                    map3.put("City", cit);
                                    map3.put("State", stat);
                                    map3.put("PinCode", pin);
                                    map3.put("Addressid", addrid);
                                    map3.put("Shipping",shipp);
                                    map3.put("Cashback",csb);
                                    map3.put("paymentmode",pymd);
                                    dr.child("User").child(user).child("Orders").child(id).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                dialogal.dismiss();
                                                finish();
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            dialogal.dismiss();
                                            finish();
                                        }
                                    });
                                }
                            });
                            dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alertDialog = dialogal.create();
                            alertDialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        getaddress();
        getname();
        getproduct();
        getstatus();
    }
    private void getstatus() {
        dr.child("User").child(user).child("Orders").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {}
                else {
                    finish();
                }
                if(dataSnapshot.child("orderstatus").getValue().toString().equals("Delivered"))
                {
                    can.setVisibility(can.GONE);
                    ret.setVisibility(ret.VISIBLE);
                    ordsts.setText(odsts);
                }
                else if(dataSnapshot.child("orderstatus").getValue().toString().equals("Confirm"))
                {
                    can.setVisibility(can.VISIBLE);
                    ret.setVisibility(ret.GONE);
                    ordsts.setText(odsts);
                }
                else if(dataSnapshot.child("orderstatus").getValue().toString().equals("Cancelled"))
                {
                    can.setVisibility(can.GONE);
                    ordsts.setText("Order Cancelled !!");
                    ret.setVisibility(ret.GONE);
                }
                else if(dataSnapshot.child("orderstatus").getValue().toString().equals("Return"))
                {
                    can.setVisibility(can.GONE);
                    ret.setVisibility(ret.GONE);
                    ordsts.setText("Order Return is in Process!!");
                }
                else
                {
                    can.setVisibility(can.GONE);
                    ret.setVisibility(ret.GONE);
                    ordsts.setText(odsts);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    //getting product details
    private void getproduct() {
        FirebaseRecyclerOptions<ordereddetailsdata> optioncart = new FirebaseRecyclerOptions.Builder<ordereddetailsdata>()
                .setQuery(dr.child("Orders").child(user).child(id), ordereddetailsdata.class).build();
        FirebaseRecyclerAdapter<ordereddetailsdata, ordereddetailsviewholder> adapter = new
                FirebaseRecyclerAdapter<ordereddetailsdata, ordereddetailsviewholder>(optioncart) {
                    @Override
                    protected void onBindViewHolder(@NonNull final ordereddetailsviewholder ordereddetailsviewholder,
                                                    int i, @NonNull
                                                    final ordereddetailsdata ordereddetailsdata) {
                        //getting value from database
                        ordereddetailsviewholder.id.setText("Product Id : "+ordereddetailsdata.getProid());
                        ordereddetailsviewholder.qt.setText("Quantity : "+ordereddetailsdata.getQuantity());
                        ordereddetailsviewholder.nm.setText("Product Name : "+ordereddetailsdata.getProname());
                        ordereddetailsviewholder.dpr.setText("Price : " + ordereddetailsdata.getDisprice() + " Rs/- प्रत्येक के लिए !!");
                        if(ordereddetailsdata.getOgprice().equals("0"))
                        {
                            ordereddetailsviewholder.opri.setVisibility(View.GONE);
                        }
                        else
                        {
                            ordereddetailsviewholder.opri.setText(ordereddetailsdata.getOgprice()+" Rs/-");
                        }
                        Picasso.get().load(ordereddetailsdata.getProimage()).into(ordereddetailsviewholder.proim);
                        //total based on items
                        Integer totalprice = Integer.parseInt(ordereddetailsdata.getDisprice()) *
                                Integer.parseInt(ordereddetailsdata.getQuantity());
                        ordereddetailsviewholder.tot.setText("Total : "+totalprice+" Rs/-");
                        //onclick
                        ordereddetailsviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // custom dialog
                                dialog = new Dialog(ordereddetails.this);
                                dialog.setContentView(R.layout.orderedproductdetail);
                                dialog.setCanceledOnTouchOutside(false);
                                dialog.setCancelable(false);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                // set the custom dialog components - text, image and button
                                TextView pid = dialog.findViewById(R.id.proid);
                                TextView disp = dialog.findViewById(R.id.dispached);
                                TextView odshipped = dialog.findViewById(R.id.ordershipped);
                                TextView outdilv = dialog.findViewById(R.id.outdelivery);
                                TextView deliveredpro = dialog.findViewById(R.id.Delivered);
                                ImageView proim=dialog.findViewById(R.id.proimage);
                                TextView sold=dialog.findViewById(R.id.soldby);
                                pid.setText("Product ID : "+ordereddetailsdata.getProid());
                                disp.setText("Product Dispached : "+ordereddetailsdata.getDispached());
                                odshipped.setText("Product Shipped : "+ordereddetailsdata.getOrdershipped());
                                outdilv.setText("Product Out for Delivery : "+ordereddetailsdata.getOutdelivery());
                                deliveredpro.setText("Product Delivered : "+ordereddetailsdata.getDelivered());
                                sold.setText("Sold By : "+ordereddetailsdata.getSoldby());
                                Picasso.get().load(ordereddetailsdata.getProimage()).into(proim);
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialog.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                lp.gravity = Gravity.CENTER;
                                dialog.getWindow().setAttributes(lp);
                                Button can = dialog.findViewById(R.id.canc);
                                can.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.dismiss();
                                    }
                                });
                                dialog.show();
                            }
                        });
                        ordereddetailsviewholder.proim.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent in = new Intent(ordereddetails.this, itemsdetails.class);
                                in.putExtra("pid", ordereddetailsdata.getProid());
                                in.putExtra("category", ordereddetailsdata.getCategory());
                                in.putExtra("disprice", ordereddetailsdata.getDisprice());
                                in.putExtra("ogpri",ordereddetailsdata.getOgprice());
                                startActivity(in);
                            }
                        });
                    }
                    @NonNull
                    @Override
                    public ordereddetailsviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate
                                (R.layout.ordereditemsdetails, parent, false);
                        ordereddetailsviewholder holder = new ordereddetailsviewholder(view);
                        return holder;
                    }
                };
        //recycler setting
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }
    //getting user details
    private void getname() {
        dr.child("User").child(user).child("Profile").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String usname = dataSnapshot.child("UserName").getValue().toString();
                String phno = dataSnapshot.child("PhoneNumber").getValue().toString();
                usrnm.setText("Dilevery To : "+usname);
                mono.setText("Mob No : "+phno);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    //getting user address details
    private void getaddress() {
                street.setText(str);
                lm.setText(la);
                cy.setText(cit);
                pc.setText(" - "+pin);
                streetb.setText(str);
                lmb.setText(la);
                cyb.setText(cit);
                pcb.setText(" - "+pin);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}