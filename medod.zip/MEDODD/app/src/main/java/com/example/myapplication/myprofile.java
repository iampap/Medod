package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Application;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
public class myprofile extends AppCompatActivity {
    //binding
    EditText na,ph;
    TextView em;
    Button up;
    //string for set up in database
    private String email , usname , mobno , image , imgurl;
    //image
    private ImageView proimage;
    private static final int gallpic = 1;
    private Uri imguri;
    //firebase
    private DatabaseReference references;
    private StorageReference prostroref;
    FirebaseAuth mauth;
    FirebaseUser fuser;
    //progress bar
    private ProgressDialog bar;
    //Toast
    private Toast toast;
    //on start of activity load data
    public  void onStart(){
        super.onStart();
        references.child("Profile").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String usname = dataSnapshot.child("UserName").getValue().toString();
                String eml = dataSnapshot.child("UserEmail").getValue().toString();
                String phno = dataSnapshot.child("PhoneNumber").getValue().toString();
                if (dataSnapshot.child("image").exists()) {
                    image = dataSnapshot.child("image").getValue().toString();
                }
                //load image
                /*references.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("image").exists()) {
                            String im = dataSnapshot.child("image").getValue().toString();
                            Picasso.get().load(im).into(proimage);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Plz Add Image!!",Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });*/
                na.setText(usname);
                em.setText(eml);
                ph.setText(phno);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        //binding
        na =(EditText)findViewById(R.id.name);
        em = (TextView) findViewById(R.id.email);
        ph = (EditText)findViewById(R.id.phone);
        up = (Button)findViewById(R.id.update);
        proimage = (ImageView)findViewById(R.id.userimg);
        bar = new ProgressDialog(myprofile.this);
        //firebase binding
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        references = FirebaseDatabase.getInstance().getReference().child("User").child(fuser.getUid());
        prostroref  = FirebaseStorage.getInstance().getReference().child("User Image").child(fuser.getUid());
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION,
                WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        //on click
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateuser();
            }
        });
        proimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenGallery();
            }
        });
    }
    //update data in user profile
    private void updateuser() {
        email = em.getText().toString().trim();
        usname = na.getText().toString().trim();
        mobno=ph.getText().toString().trim();
        if (usname.isEmpty()) {
            na.setError("Name please..");
            na.requestFocus();
            return;
        }
        else if (mobno.isEmpty()) {
            ph.setError("Mob No please..");
            ph.requestFocus();
            return;
        }
        else if(mobno.length() < 10){
            ph.setError("Enter Correct Moblie No..");
            ph.requestFocus();
            return;
        }
        else{
            if(imguri == null)
            {
                saveuserdata();
            }
            else {
                storeinformation();
            }
        }
    }
    //saving data without image
    private void saveuserdata() {
        HashMap<String, String> map = new HashMap<>();
        map.put("UserName", usname);
        map.put("UserEmail", email);
        map.put("PhoneNumber", mobno);
        map.put("image",image);
        map.put("userid",fuser.getUid());
        references.child("Profile").setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    bar.dismiss();
                    toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else
                {
                    bar.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //stroing the image from user
    private void storeinformation() {
        bar.setTitle("Updating (कृपया रुकिये)!!");
        bar.setMessage("Hang On, Updating your Profile takes less than a minute!!");
        bar.setCanceledOnTouchOutside(false);
        bar.setCancelable(false);
        bar.show();
//        upload image in database storage
        final StorageReference filepath = prostroref.child(imguri.getEncodedPath()+".jpg");
        final UploadTask uploadTask = filepath.putFile(imguri);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String mess = e.toString();
                Toast.makeText(getApplicationContext(),"Error" + mess,Toast.LENGTH_SHORT);
                bar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw task.getException();
                        }
                        //taking the image url to set in the database
                        imgurl = filepath.getDownloadUrl().toString();
                        return filepath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            imgurl = task.getResult().toString();
                            Toast.makeText(getApplicationContext(),imgurl,Toast.LENGTH_SHORT).show();
                            //call the func
                            saveproinfodatbase();
                        }
                    }
                });
            }
        });
    }
    //saving all the data in the user database
    private void saveproinfodatbase() {
        HashMap<String, String> map = new HashMap<>();
        map.put("UserName", usname);
        map.put("UserEmail", email);
        map.put("PhoneNumber", mobno);
        map.put("image",imgurl);
        map.put("userid",fuser.getUid());
        references.child("Profile").setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    bar.dismiss();
                    toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else
                {
                    bar.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //to take image from user
    private void OpenGallery()
    {
        Intent in = new Intent();
        in.setAction(Intent.ACTION_GET_CONTENT);
        in.setType("image/*");
        startActivityForResult(in,gallpic);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == gallpic && resultCode == RESULT_OK && data!=null)
        {
            imguri = data.getData();
            proimage.setImageURI(imguri);
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}