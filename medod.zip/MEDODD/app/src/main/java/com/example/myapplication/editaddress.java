package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class editaddress extends AppCompatActivity {
    //binding
    private TextView hn,lm,cy,st,pc;
    private Button upaddr;
    private String addrid,str,la,cit,sta,pin;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //toast
    private Toast toast;
    //alertdialoge
    private AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editaddress);
        //binding
        hn = findViewById(R.id.text_houseno);
        lm = findViewById(R.id.text_landmarg);
        cy = findViewById(R.id.text_city);
        st = findViewById(R.id.text_state);
        pc = findViewById(R.id.text_pincode);
        upaddr = findViewById(R.id.button_addaddr);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        dref= FirebaseDatabase.getInstance().getReference();
        //getintent
        addrid=getIntent().getExtras().get("addreddid").toString();
        str=getIntent().getExtras().get("address").toString();
        la=getIntent().getExtras().get("landmarg").toString();
        cit=getIntent().getExtras().get("city").toString();
        sta=getIntent().getExtras().get("state").toString();
        pin=getIntent().getExtras().get("pincode").toString();
        //settext
        hn.setText(str);
        lm.setText(la);
        cy.setText(cit);
        st.setText(sta);
        pc.setText(pin);
        //click
        upaddr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hn.getText().toString().trim().equals(str) && lm.getText().toString().trim().equals(la) &&
                        cy.getText().toString().trim().equals(cit) && st.getText().toString().trim().equals(sta) &&
                        pc.getText().toString().trim().equals(pin))
                {
                    toast = Toast.makeText(getApplicationContext(),"Address Exist (कृपया पता अपडेट करें)!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else {
                    updateaddr();
                }
            }
        });
    }
    //updating address
    private void updateaddr() {
        final String street = hn.getText().toString().trim();
        final String land = lm.getText().toString().trim();
        final String ci = cy.getText().toString().trim();
        final String stat = st.getText().toString().trim();
        final String pi= pc.getText().toString().trim();
        if (street.isEmpty()) {
            hn.setError("Address please..");
            hn.requestFocus();
            return;
        }
        else if (land.isEmpty()) {
            lm.setError("LandMarg please..");
            lm.requestFocus();
            return;
        }
        else if (ci.isEmpty()) {
            cy.setError("City please..");
            cy.requestFocus();
            return;
        }
        else if (stat.isEmpty()) {
            st.setError("State please..");
            st.requestFocus();
            return;
        }
        else if (pi.isEmpty()) {
            pc.setError("PinCode please..");
            pc.requestFocus();
            return;
        }
        else{
            //alert
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("Updating (कृपया रुकिये)");
            dialog.setMessage("Hang On, Updating your Address!!");
            dialog.setCancelable(false);
            alertDialog = dialog.create();
            alertDialog.show();
            //updating address
            HashMap<String, String> map = new HashMap<>();
            map.put("Street", street);
            map.put("LandMarg", land);
            map.put("City", ci);
            map.put("State", stat);
            map.put("PinCode", pi);
            map.put("Addressid", addrid);
                dref.child("User").child(fuser.getUid()).child("Address").child(addrid).setValue(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        alertDialog.dismiss();
                        toast = Toast.makeText(getApplicationContext(),"Address Updated!!",Toast.LENGTH_SHORT);
                        toast();
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        alertDialog.dismiss();
                        toast = Toast.makeText(getApplicationContext(),"Not Updated!!",Toast.LENGTH_SHORT);
                        toast();
                    }
                });
            }
        }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}