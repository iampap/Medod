package com.example.myapplication;

public class ordereddata{
    //string for values extracted from database
    private String TotalPrice,Orderid,Orderdate,Ordertime,DeliveryDate,Street,LandMarg,City,State,
            PinCode,Addressid,Shipping,Cashback,orderstatus,paymentmode;
    //default constructor
    public ordereddata() {
    }
    //constructor
    public ordereddata(String totalPrice, String orderid, String orderdate, String ordertime, String deliveryDate, String street,
    String landMarg, String city, String state, String pinCode, String addressid, String shipping, String cashback, String orderstatus,
    String paymentmode) {
        TotalPrice = totalPrice;
        Orderid = orderid;
        Orderdate = orderdate;
        Ordertime = ordertime;
        DeliveryDate = deliveryDate;
        Street = street;
        LandMarg = landMarg;
        City = city;
        State = state;
        PinCode = pinCode;
        Addressid = addressid;
        Shipping = shipping;
        Cashback = cashback;
        this.orderstatus = orderstatus;
        this.paymentmode = paymentmode;
    }
    //getter and setter
    public String getCity() {
        return City;
    }
    public void setCity(String city) {
        City = city;
    }
    public String getLandMarg() {
        return LandMarg;
    }
    public void setLandMarg(String landMarg) {
        LandMarg = landMarg;
    }
    public String getPinCode() {
        return PinCode;
    }
    public void setPinCode(String pinCode) {
        PinCode = pinCode;
    }
    public String getState() {
        return State;
    }
    public void setState(String state) {
        State = state;
    }
    public String getStreet() {
        return Street;
    }
    public void setStreet(String street) {
        Street = street;
    }
    public String getAddressid() {
        return Addressid;
    }
    public void setAddressid(String addressid) {
        Addressid = addressid;
    }
    public String getDeliveryDate() {
        return DeliveryDate;
    }
    public void setDeliveryDate(String deliveryDate) {
        DeliveryDate = deliveryDate;
    }
    public String getOrderid() {
        return Orderid;
    }
    public void setOrderid(String orderid) {
        Orderid = orderid;
    }
    public String getOrderdate() {
        return Orderdate;
    }
    public void setOrderdate(String orderdate) {
        Orderdate = orderdate;
    }
    public String getTotalPrice() {
        return TotalPrice;
    }
    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }
    public String getOrdertime() {
        return Ordertime;
    }
    public void setOrdertime(String ordertime) {
        Ordertime = ordertime;
    }

    public String getShipping() {
        return Shipping;
    }
    public void setShipping(String shipping) {
        Shipping = shipping;
    }
    public String getCashback() {
        return Cashback;
    }
    public void setCashback(String cashback) {
        Cashback = cashback;
    }
    public String getOrderstatus() {
        return orderstatus;
    }
    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }
    public String getPaymentmode() {
        return paymentmode;
    }
    public void setPaymentmode(String paymentmode) {
        this.paymentmode = paymentmode;
    }
}

