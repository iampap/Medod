package com.example.myapplication;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class placeholder extends RecyclerView.ViewHolder implements View.OnClickListener {
     TextView txtproname, textprodesc,textproprice,txtofprice,txtofpercent,bnk;
     ImageView proimg,carttx,chk;
    public itemclicklistner itemclick;
    public placeholder(@NonNull View itemView) {
        super(itemView);
        proimg = (ImageView) itemView.findViewById(R.id.proimg);
        txtproname = (TextView)itemView.findViewById(R.id.proname);
        textprodesc = (TextView)itemView.findViewById(R.id.prodesc);
        textproprice = (TextView)itemView.findViewById(R.id.proprice);
        txtofpercent = (TextView)itemView.findViewById(R.id.ofpropricepercent);
        txtofprice = (TextView)itemView.findViewById(R.id.ofproprice);
        bnk = (TextView)itemView.findViewById(R.id.blank);
        carttx = (ImageView) itemView.findViewById(R.id.addtocart);
        chk = (ImageView) itemView.findViewById(R.id.check);
        txtofprice.setBackgroundResource(R.drawable.strikeline);
    }
    @Override
    public void onClick(View v) {
    }
    public void setItemclick(itemclicklistner itemclick) {
        this.itemclick = itemclick;
    }
}
