package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class account extends Fragment {
    //binding
    private TextView name,mypro,addres,signout,login,contus,delete,inp,inadd;
    private ImageView im,pro,ad,del,out,lin,cus;
    //firestore
    private FirebaseAuth mAuth;
    private FirebaseUser firebaseUser;
    private FirebaseFirestore fs;
    private DatabaseReference references;
    private FirebaseDatabase db;
    //Toast
    private Toast toast;
    //loading the content on the start of activity
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        updateUI(firebaseUser);
        //for loading the user image
        if (firebaseUser != null) {
            references = db.getInstance().getReference();
            references.child("User").child(firebaseUser.getUid()).child("Profile").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("image").exists()) {
                        String ima = dataSnapshot.child("image").getValue().toString();
                        Picasso.get().load(ima).into(im);
                    } else {
                        Picasso.get().load(R.drawable.ic_boy).into(im);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, null);
        //binding
        im = (ImageView)view.findViewById(R.id.imageviewacc);
        pro = (ImageView)view.findViewById(R.id.immypro);
        ad = (ImageView)view.findViewById(R.id.imadd);
        del = (ImageView)view.findViewById(R.id.imdel);
        out = (ImageView)view.findViewById(R.id.out);
        lin = (ImageView)view.findViewById(R.id.log);
        cus = (ImageView)view.findViewById(R.id.us);
        login=(TextView)view.findViewById(R.id.textviewlogin);
        name = (TextView) view.findViewById(R.id.textViewuser);
        mypro =(TextView) view.findViewById(R.id.textViewmyprofile);
        addres = (TextView) view.findViewById(R.id.textViewaddress);
        signout = (TextView) view.findViewById(R.id.textViewsignout);
        delete = (TextView) view.findViewById(R.id.textViewdelete);
        contus = (TextView)view.findViewById(R.id.textviewcontactus);
        inp=view.findViewById(R.id.proin);
        inadd=view.findViewById(R.id.addin);
        //for firebase authentication
        mAuth = FirebaseAuth.getInstance();
        firebaseUser = mAuth.getCurrentUser();
        fs =FirebaseFirestore.getInstance();
        //onclick activity
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), loginactivity.class);
                startActivity(in);
            }
        });
        lin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), loginactivity.class);
                startActivity(in);
            }
        });
        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(getContext(), BNA.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(getContext(), BNA.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
        mypro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), myprofile.class);
                startActivity(intent);
            }
        });
        pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), myprofile.class);
                startActivity(intent);
            }
        });
        inp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), myprofile.class);
                startActivity(intent);
            }
        });
        addres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), address.class);
                startActivity(intent);
            }
        });
        ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), address.class);
                startActivity(intent);
            }
        });
        inadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), address.class);
                startActivity(intent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete();
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete();
            }
        });
        contus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), contactus.class);
                startActivity(intent);
            }
        });
        cus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), contactus.class);
                startActivity(intent);
            }
        });
        return view;
    }
//    for setting of buttons visible or not
    private void updateUI(FirebaseUser user) {
        if (user != null) {
            pro.setVisibility(pro.VISIBLE);
            inp.setVisibility(inp.VISIBLE);
            inadd.setVisibility(inp.VISIBLE);
            ad.setVisibility(ad.VISIBLE);
            out.setVisibility(out.VISIBLE);
            del.setVisibility(del.VISIBLE);
            lin.setVisibility(lin.GONE);
            cus.setVisibility(cus.GONE);
            login.setVisibility(login.GONE);
            mypro.setVisibility(mypro.VISIBLE);
            addres.setVisibility(addres.VISIBLE);
            signout.setVisibility(signout.VISIBLE);
            contus.setVisibility(contus.GONE);
            delete.setVisibility(delete.VISIBLE);
            name.setText(firebaseUser.getEmail());
            im.setVisibility(im.VISIBLE);
        }else {
            pro.setVisibility(pro.GONE);
            ad.setVisibility(ad.GONE);
            inp.setVisibility(inp.GONE);
            inadd.setVisibility(inp.GONE);
            out.setVisibility(out.GONE);
            del.setVisibility(del.GONE);
            lin.setVisibility(lin.VISIBLE);
            cus.setVisibility(cus.VISIBLE);
            login.setVisibility(login.VISIBLE);
            mypro.setVisibility(mypro.GONE);
            addres.setVisibility(addres.GONE);
            signout.setVisibility(signout.GONE);
            contus.setVisibility(contus.VISIBLE);
            delete.setVisibility(delete.GONE);
            name.setVisibility(name.GONE);
            im.setVisibility(im.GONE);
        }
    }
    //for delete of acc from database
    public void delete(){
        references.child("User").child(firebaseUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("Orders").exists() || dataSnapshot.child("Cart List").exists()) {
                    toast = Toast.makeText(getContext(),"Please Delete the Cart Items or the Order Items," +
                            " Before deleting the Account!!",Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER_VERTICAL,1,1);
                    toast();
                }
                else {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                    dialog.setTitle("Are You Sure!!");
                    dialog.setMessage("Deleting this Account will completely result in Removing your Acccount");
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            AlertDialog.Builder dialogdel = new AlertDialog.Builder(getActivity());
                            dialogdel.setTitle("Deleting Account!!");
                            dialogdel.setMessage("Plz wait, while Deleting Your Account");
                            dialogdel.setCancelable(false);
                            final AlertDialog alertDialogdel = dialogdel.create();
                            alertDialogdel.show();
                            firebaseUser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        mAuth.signOut();
                                        fs.collection("Address").document(firebaseUser.getUid()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                references.child("User").child(firebaseUser.getUid()).removeValue();
                                                Intent intent = new Intent(getContext(), BNA.class);
                                                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(intent);
                                                alertDialogdel.dismiss();
                                                toast = Toast.makeText(getActivity(),"Account Deleted",Toast.LENGTH_LONG);
                                                toast();
                                            }
                                        });
                                    }
                                    else
                                    {
                                        alertDialogdel.dismiss();
                                        Toast.makeText(getActivity(),task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }
                    });
                    dialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    AlertDialog alertDialog = dialog.create();
                    alertDialog.show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });

    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}