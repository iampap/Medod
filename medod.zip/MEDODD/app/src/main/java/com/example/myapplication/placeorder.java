package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SearchRecentSuggestionsProvider;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Nullable;

public class placeorder extends AppCompatActivity {
    //binding
    private String totamt,user,pid,cashback;
    private String orderid,currenttime, currentdate,resultdate ;
    private String [] pids,cate,qt,pname,pimg,pdpri,popri;  //strings for save values from cart items like pid , category, quantity
    private String st=null,lm,ct,sta,pin,addid;
    //recycler
    private RecyclerView recyclerView,recyclerViewaddress;
    private RecyclerView.LayoutManager layoutManager,layoutManageraddr;
    //binding
    private TextView total ,dilevery,cashb,urnm,urmob;
    private Button confirm;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref,oref;
    //get pincode
    private ArrayList<String> pincd = new ArrayList<String>();
    //toast
    private Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placeorder);
        //getting the total amt from previous activity
        totamt = getIntent().getStringExtra("total price");
        cashback = getIntent().getStringExtra("cashback");
        //binding
        dilevery = (TextView)findViewById(R.id.dileverydate);
        confirm = (Button)findViewById(R.id.placeorder);
        total = (TextView)findViewById(R.id.itemtotalbelow);
        urnm = findViewById(R.id.usrnm);
        urmob = findViewById(R.id.usrmobno);
        cashb = findViewById(R.id.itemcashback);
        //recycler
        recyclerView = findViewById(R.id.cartrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //recycler
        recyclerViewaddress = findViewById(R.id.recycleraddr);
        recyclerViewaddress.setHasFixedSize(true);
        layoutManageraddr = new LinearLayoutManager(this);
        recyclerViewaddress.setLayoutManager(layoutManageraddr);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        dref = FirebaseDatabase.getInstance().getReference();
        //delivery date
        Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat currdate = new SimpleDateFormat(" dd:MMM:yyyy");
        calfordate.add(Calendar.DATE, 3);
        resultdate = currdate.format(calfordate.getTime());
        dilevery.setText(resultdate);
        //check all the necessary things while confirm
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
                dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("Address").exists()) {
                            if(TextUtils.isEmpty(st))//checking the String is empty or not
                            {
                                toast=Toast.makeText(getApplicationContext(),"Select Address!!",Toast.LENGTH_SHORT);
                                toast();
                            }
                            else
                                {
                                    dref.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            int flag = 0;
                                            if (dataSnapshot.child("pincode").exists()) {
                                                for (DataSnapshot ds : dataSnapshot.child("pincode").child("Pincode").getChildren()) {
                                                    String pico = ds.getValue().toString();
                                                    pincd.add(pico);
                                                }}
                                            for (int i = 0; i < pincd.size(); i++) {
                                                if (pincd.get(i).equals(pin.toString())) {
                                                    //calling order to place
                                                    orderplace();
                                                    Intent in = new Intent(getApplicationContext(), orderedplaced.class);
                                                    startActivity(in);
                                                    in.addFlags(in.FLAG_ACTIVITY_NO_USER_ACTION);
                                                    toast = Toast.makeText(getApplicationContext(), "Order Placed!!", Toast.LENGTH_SHORT);
                                                    toast();
                                                    finish();
                                                    flag = 1;
                                                } }
                                            if(flag == 0){
                                                toast = Toast.makeText(getApplicationContext(),"Can't Deliver to your Selected Pin-Code!!\nWe are Connecting Soon!!", Toast.LENGTH_SHORT);
                                                View view = toast.getView();
                                                view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                                                TextView text = view.findViewById(android.R.id.message);
                                                text.setTextColor(Color.BLACK);
                                                text.setTextSize(15);
                                                toast.show();
                                            }
                                        }
                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                            }
                        }
                        else {
                            toast=Toast.makeText(getApplicationContext(),"Add Address",Toast.LENGTH_SHORT);
                            toast();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }
//placing order
    private void orderplace() {
        Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat currdate = new SimpleDateFormat(" dd:MMM:yyyy");
        currentdate = currdate.format(calfordate.getTime());
        SimpleDateFormat currtime = new SimpleDateFormat("HH:MM:SS:a");
        currenttime = currtime.format(calfordate.getTime());
        //timestamp
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
        String tss = simpleDateFormat.format(calfordate.getTime());
        try{
        final Date date = simpleDateFormat.parse(tss);
        long ts = date.getTime();
            orderid=String.valueOf(ts);
        }catch(ParseException e){
            e.printStackTrace();
        }
//Date extraction from database like pid, category , quantiy
        dref = FirebaseDatabase.getInstance().getReference().child("User").child(fuser.getUid());
        oref=FirebaseDatabase.getInstance().getReference();
         final List<orderdata> pidlist = new ArrayList<>(); //for storing values in array
                    dref.child("Cart List").child("product").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                orderdata user = postSnapshot.getValue(orderdata.class);
                                pidlist.add(user);  //adding the value in array
                                pids = new String[pidlist.size()]; //adding the extracted value from database in array string
                                cate = new String[pidlist.size()];
                                qt = new String[pidlist.size()];
                                pname = new String[pidlist.size()];
                                pimg = new String[pidlist.size()];
                                pdpri = new String[pidlist.size()];
                                popri = new String[pidlist.size()];
                                for(int i=0; i < pidlist.size(); i++) { //loop for saving data in string and in database order table
                                    pids[i] = new String(pidlist.get(i).getPid());
                                    cate[i] = new String(pidlist.get(i).getCategory());
                                    qt[i] = new String(pidlist.get(i).getQuantity());
                                    pname[i] = new String(pidlist.get(i).getProname());
                                    pimg[i] = new String(pidlist.get(i).getImage());
                                    pdpri[i] = new String(pidlist.get(i).getDisprice());
                                    popri[i] = new String(pidlist.get(i).getOgprice());
                                    //saving the product data in order table
                                    HashMap<String, String> map2 = new HashMap<>();
                                    map2.put("proid", pids[i]);
                                    map2.put("category", cate[i]);
                                    map2.put("quantity", qt[i]);
                                    map2.put("proname",pname[i]);
                                    map2.put("proimage",pimg[i]);
                                    map2.put("Orderid", orderid);
                                    map2.put("disprice",pdpri[i]);
                                    map2.put("ogprice",popri[i]);
                                    map2.put("dispached","NotYet");
                                    map2.put("ordershipped","NotYet");
                                    map2.put("outdelivery","NotYet");
                                    map2.put("Delivered","NotYet");
                                    map2.put("soldby","null");
                                    oref.child("Orders").child(fuser.getUid()).child(orderid)
                                            .child("product: " + String.valueOf(i)).setValue(map2);
                                    //saving the orderdetail in user table
                                    HashMap<String, String> map3  = new HashMap<>();
                                    map3.put("TotalPrice",totamt.toString());
                                    map3.put("Orderid", orderid);
                                    map3.put("Orderdate", currentdate);
                                    map3.put("Ordertime", currenttime);
                                    map3.put("DeliveryDate", resultdate);
                                    map3.put("Street", st);
                                    map3.put("LandMarg", lm);
                                    map3.put("City", ct);
                                    map3.put("State", sta);
                                    map3.put("PinCode", pin);
                                    map3.put("Addressid", addid);
                                    map3.put("Shipping","Free");
                                    map3.put("Cashback",cashback.toString());
                                    map3.put("orderstatus","NotConfirm");
                                    map3.put("paymentmode","Cash");
                                    dref.child("Orders").child(orderid).setValue(map3);
                                    //deleting the cart value
                                    dref.child("Cart List").removeValue();
                                    //removing the onging process of refrence
                                    dref.removeEventListener(this);
                                    oref.removeEventListener(this);
                                }
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    });
    }
    //on start load the data
    @Override
    protected void onStart() {
        super.onStart();
        getusrdet();
        //total price of order
        total.setText(totamt.toString() +" Rs /-");
        cashb.setText(cashback.toString()+" Rs /-");
        final DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
        FirebaseRecyclerOptions<orderdata> optioncart = new FirebaseRecyclerOptions.Builder<orderdata>()
                .setQuery(dref.child("User").child(fuser.getUid()).child("Cart List").
                        child("product"),orderdata.class).build();
        FirebaseRecyclerAdapter<orderdata, orderviewholder> adapter = new FirebaseRecyclerAdapter<orderdata, orderviewholder>(optioncart) {
            @Override
            protected void onBindViewHolder(@NonNull orderviewholder orderviewholder, int i, @NonNull orderdata orderdata) {
                //getting the cart data to show
                orderviewholder.itname.setText(orderdata.getProname());
                orderviewholder.itdisprice.setText(orderdata.getDisprice()+ " Rs /- For Each");
                orderviewholder.itquantity.setText("Quantity: " + orderdata.getQuantity());
                Picasso.get().load(orderdata.getImage()).into(orderviewholder.itimage);
                if(orderdata.getOgprice().equals("0"))
                {
                    orderviewholder.itogprice.setVisibility(View.GONE);
                    orderviewholder.itoffper.setVisibility(View.GONE);
                }
                else
                {
                    double  pri = Integer.parseInt(orderdata.getDisprice());
                    double  off = Integer.parseInt(orderdata.getOgprice());
                    double  diff = off - pri ;
                    int  perof = (int) ((diff / off) * 100);
                    orderviewholder.itoffper.setText(String.valueOf(perof)+"% OFF");
                    orderviewholder.itogprice.setText(orderdata.getOgprice()+" Rs/-");
                }
                orderviewholder.ittot.setText("Total  "+String.valueOf(Integer.parseInt(orderdata.getDisprice())*
                        Integer.parseInt(orderdata.getQuantity()))+" Rs/-");
                pid = orderdata.getPid();
            }
            @NonNull
            @Override
            public orderviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orderitems,parent,false);
                orderviewholder holder = new orderviewholder(view);
                return holder;
            }
        };
        recyclerView.setAdapter(adapter);
        adapter.startListening();
        getaddress();
    }
    private void getusrdet() {
        final DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
        dref.child("User").child(fuser.getUid()).child("Profile").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                urnm.setText("Delivery to "+dataSnapshot.child("UserName").getValue().toString());
                urmob.setText("Mobile No "+dataSnapshot.child("PhoneNumber").getValue().toString());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    //getting address
    private void getaddress() {
        final DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
        FirebaseRecyclerOptions<orderdataaddredddata> optioncartadd = new FirebaseRecyclerOptions.Builder<orderdataaddredddata>()
                .setQuery(dref.child("User").child(fuser.getUid()).child("Address"), orderdataaddredddata.class).build();
        FirebaseRecyclerAdapter<orderdataaddredddata, orderdataaddressviewholder> adapteradd = new
                FirebaseRecyclerAdapter<orderdataaddredddata, orderdataaddressviewholder>(optioncartadd) {
                    @Override
                    protected void onBindViewHolder(@NonNull final orderdataaddressviewholder orderdataaddressviewholder,
                                                    final int i, @NonNull
                                                    final orderdataaddredddata orderdataaddredddata) {
                        //getting value from database
                        orderdataaddressviewholder.streetad.setText("Address : "+orderdataaddredddata.getStreet());
                        orderdataaddressviewholder.lm.setText("LandMarg : "+orderdataaddredddata.getLandMarg());
                        orderdataaddressviewholder.sta.setText("State : "+orderdataaddredddata.getState());
                        orderdataaddressviewholder.pc.setText("PinCode : "+orderdataaddredddata.getPinCode());
                        orderdataaddressviewholder.cy.setText("City : "+orderdataaddredddata.getCity());
                        final String addressid = orderdataaddredddata.getAddressid();
                        orderdataaddressviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                orderdataaddressviewholder.itemView.setBackgroundColor(Color.LTGRAY);
                                notifyDataSetChanged();
                                addid=addressid;
                                st=orderdataaddredddata.getStreet();
                                lm=orderdataaddredddata.getLandMarg();
                                sta=orderdataaddredddata.getState();
                                pin=orderdataaddredddata.getPinCode();
                                ct=orderdataaddredddata.getCity();
                                toast=Toast.makeText(getApplicationContext(),"Address Selected with PinCode : "+pin,Toast.LENGTH_SHORT);
                                toast();
                            }
                        });
                        orderdataaddressviewholder.itemView.setOnTouchListener(new View.OnTouchListener() {
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {
                                if(event.getAction() == MotionEvent.ACTION_CANCEL)
                                {
                                    v.setBackgroundColor(Color.WHITE);
                                }
                                return false;
                            }
                        });
                        orderdataaddressviewholder.dele.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dref.child("User").child(fuser.getUid()).child("Address").child(orderdataaddredddata.getAddressid()).removeValue();
                            }
                        });
                        orderdataaddressviewholder.ed.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent in = new Intent(placeorder.this,editaddress.class);
                                in.putExtra("addreddid",orderdataaddredddata.getAddressid());
                                in.putExtra("address",orderdataaddredddata.getStreet());
                                in.putExtra("landmarg",orderdataaddredddata.getLandMarg());
                                in.putExtra("state",orderdataaddredddata.getState());
                                in.putExtra("pincode",orderdataaddredddata.getPinCode());
                                in.putExtra("city",orderdataaddredddata.getCity());
                                startActivity(in);
                            }
                        });
                    }
                    @NonNull
                    @Override
                    public orderdataaddressviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate
                                (R.layout.orderitemsaddress, parent, false);
                        final orderdataaddressviewholder holder = new orderdataaddressviewholder(view);
                  return holder;
                    }
                };
        //recycler setting
        recyclerViewaddress.setAdapter(adapteradd);
        adapteradd.startListening();
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}