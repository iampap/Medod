package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class orderdataaddressviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView streetad,lm,cy,sta,pc,coun;
    ImageView ed,dele;
    public itemclicklistner orderaddressclick;
    public orderdataaddressviewholder(@NonNull View itemView) {
        super(itemView);
        //binding
        streetad =itemView.findViewById(R.id.streetp);
        lm = itemView.findViewById(R.id.landmargp);
        cy = itemView.findViewById(R.id.cityp);
        sta =itemView.findViewById(R.id.statep);
        pc =itemView.findViewById(R.id.pincodep);
        coun =itemView.findViewById(R.id.countryp);
        ed = itemView.findViewById(R.id.addedit);
        dele =itemView.findViewById(R.id.adddelete);
    }
    public void setOrderaddressclick(itemclicklistner orderaddressclick) {
        this.orderaddressclick = orderaddressclick;
    }
    public void onClick(View v) {
    }
}
