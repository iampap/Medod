package com.example.myapplication;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.text.style.BackgroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.style.Circle;
import com.github.ybq.android.spinkit.style.WanderingCubes;
import com.github.ybq.android.spinkit.style.Wave;
import com.google.api.Distribution;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.collection.LLRBNode;
import com.squareup.picasso.Picasso;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

class MySingletonClass {
    private static MySingletonClass instance;
    public static MySingletonClass getInstance() {
        if (instance == null)
            instance = new MySingletonClass();
        return instance;
    }
    private MySingletonClass() {
    }
    private String val = "0";
    public String getValue() {
        return val;
    }
    public void setValue(String value) {
        this.val = value;
    }
}
class pincode {
    private static pincode instance;
    public static pincode getInstance() {
        if (instance == null)
            instance = new pincode();
        return instance;
    }
    private pincode() {
    }
    private ArrayList<String> availableusrpincd = new ArrayList<String>();
    public ArrayList<String> getValue() {
        return availableusrpincd;
    }
    public void setValue(ArrayList<String> availableusrpincd) {
        this.availableusrpincd = availableusrpincd;
    }
}
public class home extends Fragment {
    //binding
    TextView na;
    private ImageView immsk,therm,imasani,imaww,gotocart,fa,usrimg,search;
    private ImageView bp,sg,ne,in,ay,he,me,ba,di,nu,chpn;
    private TextView ayt,het,met,bat,dit,nut,immskt,thermt,imasanit,imawwt,crtcnt;
    //for image show
    ViewPager viewPager;
    int currentPage = 0;
    Timer timer;
    final long DELAY_MS = 500;//delay in milliseconds before task is to be executed
    final long PERIOD_MS = 3000;
    //database
    private DatabaseReference references;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //toast
    private Toast toast;
    //grid layout
    private LinearLayout llayout,tlayout,slayout,wlayout;
    //array
    private ArrayList<String> pincd = new ArrayList<String>();
    private ArrayList<String> usrpincd = new ArrayList<String>();
    private ArrayList<String> apc = new ArrayList<String>();
    private ArrayList<String> cartitems = new ArrayList<String>();
    //dialog
    private Dialog dialog,loaderdialog;
    //progress bar
    private ProgressDialog bar;
    //loader
    private WanderingCubes mCircleDrawable;
    //refresh
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_CANCELED) {
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,new home()).remove(home.this);
                ft.commit();
            }
        }
    }
    //onactivity start to load
    @Override
    public void onStart() {
        super.onStart();
        //if the current user is empty
        if (fuser != null) {
            //getting username from database
            references.child("User").child(fuser.getUid()).child("Profile").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    assert dataSnapshot != null;
                    //if the user image exist
                    if (dataSnapshot.child("image").exists()) {
                        //load image to image view
                        String im = dataSnapshot.child("image").getValue().toString();
                        Picasso.get().load(im).into(usrimg);
                        loaderdialog.dismiss();
                        mCircleDrawable.stop();
                    }
                    else {
                        Picasso.get().load(R.drawable.ic_boy).into(usrimg);
                        loaderdialog.dismiss();
                        mCircleDrawable.stop();
                    }
                    //setting the user name
                    String usname = dataSnapshot.child("UserName").getValue().toString();
                    if(usname.contains(" ")){
                        String nam = usname.substring(0, usname.indexOf(" "));
                        na.setText("Hii  "+nam+" !!");
                        loaderdialog.dismiss();
                        mCircleDrawable.stop();
                    }
                    else {
                        na.setText("Hii  "+usname+" !!");
                        loaderdialog.dismiss();
                        mCircleDrawable.stop();
                    }
                    references.removeEventListener(this);
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                }
            });
        }
        //yes then show
        else {
            na.setText("Login Please!!, We Insist..");
            loaderdialog.dismiss();
            mCircleDrawable.stop();
            na.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = new Intent(getContext(), loginactivity.class);
                    startActivity(in);
                }
            });
        }
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, null);
        viewPager = (ViewPager) view.findViewById(R.id.viewpage);
        //image show on home page
        viewpageadpator viewpage = new viewpageadpator(getContext());
        viewPager.setAdapter(viewpage);
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == 4) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled
            @Override
            public void run() {
                handler.post(Update);
            }
        }, DELAY_MS, PERIOD_MS);
        //binding
        na = (TextView) view.findViewById(R.id.name);
        crtcnt=view.findViewById(R.id.hmitemcount);
        imasanit = (TextView) view.findViewById(R.id.imsanit);
        thermt = (TextView) view.findViewById(R.id.imthermot);
        immskt = (TextView) view.findViewById(R.id.immaskt);
        imawwt = (TextView) view.findViewById(R.id.imwwt);
        usrimg = (ImageView) view.findViewById(R.id.imageid);
        imasani = (ImageView) view.findViewById(R.id.imsani);
        therm = (ImageView) view.findViewById(R.id.imthermo);
        immsk = (ImageView) view.findViewById(R.id.immask);
        imaww = (ImageView) view.findViewById(R.id.imww);
        bp = (ImageView) view.findViewById(R.id.bp);
        sg = (ImageView) view.findViewById(R.id.sug);
        ne = (ImageView) view.findViewById(R.id.nebu);
        in = (ImageView) view.findViewById(R.id.inha);
        fa = (ImageView) view.findViewById(R.id.fakit);
        nu = (ImageView) view.findViewById(R.id.gym);
        di = (ImageView) view.findViewById(R.id.dbcare);
        ba = (ImageView) view.findViewById(R.id.baby);
        me = (ImageView) view.findViewById(R.id.med);
        he = (ImageView) view.findViewById(R.id.homeo);
        ay = (ImageView) view.findViewById(R.id.ayur);
        chpn = view.findViewById(R.id.pincodecheck);
        search = view.findViewById(R.id.searchpro);
        ayt = (TextView) view.findViewById(R.id.ayurt);
        het = (TextView) view.findViewById(R.id.homeot);
        met = (TextView) view.findViewById(R.id.medt);
        bat = (TextView) view.findViewById(R.id.babyt);
        dit = (TextView) view.findViewById(R.id.dbcaret);
        nut = (TextView) view.findViewById(R.id.gymt);
        gotocart = (ImageView) view.findViewById(R.id.cart);
        llayout = (LinearLayout) view.findViewById(R.id.face);
        tlayout = (LinearLayout) view.findViewById(R.id.ther);
        slayout = (LinearLayout) view.findViewById(R.id.sani);
        wlayout = (LinearLayout) view.findViewById(R.id.wet);
        bar = new ProgressDialog(getContext());
        //database binding
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        references = FirebaseDatabase.getInstance().getReference();
        //check the address data
        checkpincode();
        //preloader
        loader();
        //cart
        cartitm();
        //color animation in grid view
        int colorFrom = getResources().getColor(R.color.transparent);
        int colorTo = getResources().getColor(R.color.white);
        ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorFrom, colorTo);
        colorAnimation.setDuration(3000);// milliseconds
        colorAnimation.setRepeatCount(1000);
        colorAnimation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                llayout.setBackgroundColor((int) animator.getAnimatedValue());
                tlayout.setBackgroundColor((int) animator.getAnimatedValue());
                slayout.setBackgroundColor((int) animator.getAnimatedValue());
                wlayout.setBackgroundColor((int) animator.getAnimatedValue());
            }
        });
        colorAnimation.start();
        //on click on the image
        gotocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fuser != null) {
                    Intent in = new Intent(getContext(), cart.class);
                    startActivityForResult(in,1);
                } else {
                    toast = Toast.makeText(getContext(), "Login Please!!, We Insist!!", Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
        imasani.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Sanitizer");
                startActivityForResult(in,1);
            }
        });
        therm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Thermometer");
                startActivityForResult(in,1);
            }
        });
        immsk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Mask");
                startActivityForResult(in,1);
            }
        });
        imaww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Wet Wipes");
                startActivityForResult(in,1);
            }
        });
        imasanit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Sanitizer");
                startActivityForResult(in,1);
            }
        });
        thermt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Thermometer");
                startActivityForResult(in,1);
            }
        });
        immskt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Mask");
                startActivityForResult(in,1);
            }
        });
        imawwt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Wet Wipes");
                startActivityForResult(in,1);
            }
        });
        fa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "First Aid");
                startActivityForResult(in,1);
            }
        });
        ne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Nebulizer");
                startActivityForResult(in,1);
            }
        });
        in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Inhaler");
                startActivityForResult(in,1);
            }
        });
        sg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Blood Glucose");
                startActivityForResult(in,1);
            }
        });
        bp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "sphygmomanometer");
                startActivityForResult(in,1);
            }
        });
        nu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Nutrition Care");
                startActivityForResult(in,1);
            }
        });
        di.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Diabetes Care");
                startActivityForResult(in,1);
            }
        });
        ba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Baby & Mom Care");
                startActivityForResult(in,1);
            }
        });
        me.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Medicine");
                startActivityForResult(in,1);
            }
        });
        he.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Herbal");
                startActivityForResult(in,1);
            }
        });
        ay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Ayurveda");
                startActivityForResult(in,1);
            }
        });
        nut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Nutrition Care");
                startActivityForResult(in,1);
            }
        });
        dit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Diabetes Care");
                startActivityForResult(in,1);
            }
        });
        bat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Baby & Mom Care");
                startActivityForResult(in,1);
            }
        });
        met.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Medicine");
                startActivityForResult(in,1);
            }
        });
        het.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Herbal");
                startActivityForResult(in,1);
            }
        });
        ayt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), useritems.class);
                in.putExtra("category", "Ayurveda");
                startActivityForResult(in,1);
            }
        });
        chpn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fuser != null) {
                if (MySingletonClass.getInstance().getValue().equals("0")) {
                    // custom dialog
                    final Dialog dialogch = new Dialog(getContext());
                    dialogch.setContentView(R.layout.homepincodecustomdialoge);
                    dialogch.setCanceledOnTouchOutside(false);
                    dialogch.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    // set the custom dialog components - text, image and button
                    final EditText tx = dialogch.findViewById(R.id.textpin);
                    final TextView chktx = dialogch.findViewById(R.id.chkpincode);
                    final TextView addtx = dialogch.findViewById(R.id.pintextclickadr);
                    addtx.setVisibility(View.VISIBLE);
                    addtx.setText("Click to Add Address!!");
                    addtx.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent in = new Intent(getContext(), address.class);
                            startActivity(in);
                            dialogch.dismiss();
                        }
                    });
                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                    lp.copyFrom(dialogch.getWindow().getAttributes());
                    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    lp.gravity = Gravity.CENTER;
                    dialogch.getWindow().setAttributes(lp);
                    chktx.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog = new Dialog(getContext());
                            dialog.setCanceledOnTouchOutside(false);
                            dialog.setCancelable(false);
                            dialog.setContentView(R.layout.homepincodedialoge);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                            // set the custom dialog components - text, image and button
                            TextView tx = dialog.findViewById(R.id.textshowerror);
                            tx.setText(pincd.toString());
                            Button ok = dialog.findViewById(R.id.okdone);
                            ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                            lp.copyFrom(dialog.getWindow().getAttributes());
                            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                            lp.gravity = Gravity.CENTER;
                            dialog.show();
                        }
                    });
                    Button sub = dialogch.findViewById(R.id.pinsub);
                    sub.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (tx.length() < 6) {
                                tx.setError("Enter Correct PinCode!!");
                                tx.requestFocus();
                                return;
                            } else {
                                bar.setTitle("Hang On!!");
                                bar.setMessage("Plz Wait....while we are checking the pincode!!");
                                bar.setCanceledOnTouchOutside(false);
                                bar.setCancelable(false);
                                bar.show();
                                references.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        int flagpin = 0;
                                        for (int i = 0; i < pincd.size(); i++) {
                                            if (pincd.get(i).equals(tx.getText().toString())) {
                                                MySingletonClass.getInstance().setValue("1");
                                                bar.dismiss();
                                                dialogch.dismiss();
                                                toast = Toast.makeText(getContext(), "Delivery Available to your Pin-Code!!", Toast.LENGTH_SHORT);
                                                View view = toast.getView();
                                                view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                                                TextView text = view.findViewById(android.R.id.message);
                                                text.setTextColor(Color.BLACK);
                                                text.setTextSize(20);
                                                toast.show();
                                                flagpin = 1;
                                                break;
                                            }
                                        }
                                        if(flagpin == 0){
                                            toast = Toast.makeText(getContext(), "Can't Deliver to your Pin-Code!!\n" +
                                                    "We are Connecting Soon!!", Toast.LENGTH_SHORT);
                                            View view = toast.getView();
                                            view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                                            TextView text = view.findViewById(android.R.id.message);
                                            text.setTextColor(Color.BLACK);
                                            text.setTextSize(20);
                                            toast.show();
                                            bar.dismiss();
                                            dialogch.dismiss();
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        }
                    });
                    dialogch.show();
                } else {
                    dialog = new Dialog(getContext());
                    dialog.setContentView(R.layout.homeaddressdialoge);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                    // set the custom dialog components - text, image and button
                    TextView tx = dialog.findViewById(R.id.textshowerror);
                    tx.setText("Delivery is Possible at your given Pin-Code in Address!!"+"\n"+pincode.getInstance().getValue());
                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                    lp.copyFrom(dialog.getWindow().getAttributes());
                    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    lp.gravity = Gravity.CENTER;
                    dialog.show();
                }
            }
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), search.class);
                startActivityForResult(in,1);
            }
        });
        return view;
    }

    private void cartitm() {
        if (fuser != null) {
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                child("product").getChildren()) {
                            String crtitm = ds.getKey().toString();
                            cartitems.add(crtitm);
                        }
                    }
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        if (cartitems.size()>0) {
                            crtcnt.setText(String.valueOf(cartitems.size()));
                        }
                    }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        }
    }

    protected void checkpincode() {
        if (fuser != null) {
            if (MySingletonClass.getInstance().getValue().equals("0")) {
                references.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("pincode").exists()) {
                            for (DataSnapshot ds : dataSnapshot.child("pincode").child("Pincode").getChildren()) {
                                String pico = ds.getValue().toString();
                                pincd.add(pico);
                            }
                        }
                        if (dataSnapshot.child("User").child(fuser.getUid()).child("Address").exists()) {
                            for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Address").getChildren()) {
                                String pico = ds.child("PinCode").getValue().toString();
                                usrpincd.add(pico);
                            }
                        }
                        for (int i = 0; i < pincd.size(); i++) {
                            for (int j = 0; j < usrpincd.size(); j++) {
                                if (pincd.get(i).equals(usrpincd.get(j))) {
                                    MySingletonClass.getInstance().setValue("1");
                                    apc.add(usrpincd.get(j));
                                    pincode.getInstance().setValue(apc);
                                }
                            }
                        }
                        if (MySingletonClass.getInstance().getValue().equals("0")) {
                            if (dataSnapshot.child("User").child(fuser.getUid()).child("Address").exists()) {
                                //pincode dialoge
                                pincodedialogue();
                            }
                            else{
                                dialog = new Dialog(getContext());
                                dialog.setContentView(R.layout.homeaddressdialoge);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                // set the custom dialog components - text, image and button
                                TextView tx = dialog.findViewById(R.id.textshowerror);
                                tx.setTextColor(Color.parseColor("#FF0000"));
                                tx.setText("Click to Add Address");
                                tx.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent in = new Intent(getContext(), address.class);
                                        startActivity(in);
                                        dialog.dismiss();
                                    }
                                });
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialog.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                lp.gravity = Gravity.CENTER;
                                dialog.show();
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
    }
    public void pincodedialogue(){
        if (fuser != null) {
            if (MySingletonClass.getInstance().getValue().equals("0")) {
                dialog = new Dialog(getContext());
                dialog.setContentView(R.layout.homeaddressdialoge);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                // set the custom dialog components - text, image and button
                TextView tx = dialog.findViewById(R.id.textshowerror);
                TextView tx1 = dialog.findViewById(R.id.textclickadr);
                tx1.setVisibility(View.VISIBLE);
                tx.setText("Delivery is Not-Possible at your given Pin-Code in Address!!"+"\n"+usrpincd.toString());
                tx1.setTextColor(Color.parseColor("#FF0000"));
                tx1.setText("Click to change Address");
                tx1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent in = new Intent(getContext(), address.class);
                        startActivity(in);
                        dialog.dismiss();
                    }
                });
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialog.getWindow().getAttributes());
                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                lp.gravity = Gravity.CENTER;
                dialog.show();
            }
        }
    }
    public void loader(){
        loaderdialog = new Dialog(getContext());
        loaderdialog.setCanceledOnTouchOutside(false);
        loaderdialog.setCancelable(false);
        loaderdialog.setContentView(R.layout.homeaddressdialoge);
        loaderdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView tx = loaderdialog.findViewById(R.id.textshowerror);
        LinearLayout ll=loaderdialog.findViewById(R.id.loaderll);
        ll.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        mCircleDrawable = new WanderingCubes();
        mCircleDrawable.setBounds(0, 0, 100, 100);
        mCircleDrawable.setColor(Color.parseColor("#ffffff"));
        tx.setCompoundDrawables(null, null, mCircleDrawable, null);
        mCircleDrawable.start();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(loaderdialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        loaderdialog.show();
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}