package com.example.myapplication;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class addressviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView streetad,lm,cy,sta,pc,coun;
    ImageView addel,adedit;
    public itemclicklistner addressclick;
    public addressviewholder(@NonNull View itemView) {
        super(itemView);
        //binding
        streetad =itemView.findViewById(R.id.street);
        lm = itemView.findViewById(R.id.landmarg);
        cy = itemView.findViewById(R.id.city);
        sta =itemView.findViewById(R.id.state);
        pc =itemView.findViewById(R.id.pincode);
        coun =itemView.findViewById(R.id.country);
        addel = itemView.findViewById(R.id.adddelete);
        adedit=itemView.findViewById(R.id.addedit);
    }
    @Override
    public void onClick(View v) {

    }
    public void setAddressclick(itemclicklistner addressclick) {
        this.addressclick = addressclick;
    }
}
