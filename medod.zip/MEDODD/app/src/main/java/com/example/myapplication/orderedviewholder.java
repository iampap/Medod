package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class orderedviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView id,tida,tot,can,deldt;
        public itemclicklistner itemorder;
    public orderedviewholder(@NonNull View itemView) {
        super(itemView);
        id = (TextView)itemView.findViewById(R.id.odid);
        tida = (TextView)itemView.findViewById(R.id.datetime);
        tot = (TextView)itemView.findViewById(R.id.total);
        can = (TextView)itemView.findViewById(R.id.cancel);
        deldt = (TextView)itemView.findViewById(R.id.deli);
    }
    @Override
    public void onClick(View v) {}
    public void setItemorder(itemclicklistner itemorder) {
        this.itemorder = itemorder;
    }
}
