package com.example.myapplication;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Binder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class addaddress extends AppCompatActivity {
    //binding
    private TextView hn,lm,cy,st,pc;
    private Button addr;
    private String addressid;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //toast
    private Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addaddress);
        //binding
        hn = findViewById(R.id.text_houseno);
        lm = findViewById(R.id.text_landmarg);
        cy = findViewById(R.id.text_city);
        st = findViewById(R.id.text_state);
        pc = findViewById(R.id.text_pincode);
        addr = findViewById(R.id.button_addaddr);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        dref= FirebaseDatabase.getInstance().getReference();
        addr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateaddr();
            }
        });
    }
    //adding address to firestore
    private void updateaddr() {
        final String street = hn.getText().toString().trim();
        final String land = lm.getText().toString().trim();
        final String ci = cy.getText().toString().trim();
        final String stat = st.getText().toString().trim();
        final String pi= pc.getText().toString().trim();
        if (street.isEmpty()) {
            hn.setError("Address please..");
            hn.requestFocus();
            return;
        }
        if (land.isEmpty()) {
            lm.setError("LandMarg please..");
            lm.requestFocus();
            return;
        }
        if (ci.isEmpty()) {
            cy.setError("City please..");
            cy.requestFocus();
            return;
        }
        if (stat.isEmpty()) {
            st.setError("State please..");
            st.requestFocus();
            return;
        }
        if (pi.isEmpty()) {
            pc.setError("PinCode please..");
            pc.requestFocus();
            return;
        }
        //timestamp
        Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddhhmmss");
        String tss = simpleDateFormat.format(calfordate.getTime());
        try{
            final Date date = simpleDateFormat.parse(tss);
            long ts = date.getTime();
            addressid=String.valueOf(ts);
        }catch(ParseException e){
            e.printStackTrace();
        }
                    HashMap<String, String> map = new HashMap<>();
                    map.put("Street", street);
                    map.put("LandMarg", land);
                    map.put("City", ci);
                    map.put("State", stat);
                    map.put("PinCode", pi);
                    map.put("Addressid", addressid);
                    dref.child("User").child(fuser.getUid()).child("Address").child(addressid).setValue(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            toast = Toast.makeText(getApplicationContext(),"Address Added!!",Toast.LENGTH_SHORT);
                            toast();
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            toast = Toast.makeText(getApplicationContext(),"Not Added!!",Toast.LENGTH_SHORT);
                            toast();
                        }
                    });
                }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}