package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class itemsdetails extends AppCompatActivity {
    //for the item how much item to be added
    int minteger = 0;
    //cart button
    private FloatingActionButton cart;
    //binding
    private TextView name,desc,discprice,cartvalue,topitname,ogprice,peroff,prooverview,prodingredients,prodosage,prolife,
            pronetquantity,probrandabout,procaution,proinfo,procertification,prid,cntcrt;
    private ImageView itemima,cartitem,srch;
    private  String productid="",it,dpri,opri;
    private int perof;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    private String img;
    //toast
    private Toast toast;
    //dialog
    private Dialog dialog;
    //array
    private ArrayList<String> match = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itemsdetails);
        //getting the intent from back activity for the load of that particular item from database
        productid = getIntent().getStringExtra("pid");
        it = getIntent().getStringExtra("category");
        dpri=getIntent().getStringExtra("disprice");
        opri=getIntent().getStringExtra("ogpri");
        //binding
        topitname = findViewById(R.id.prname);
        name = (TextView)findViewById(R.id.textitemname);
        cntcrt=findViewById(R.id.itemdetcount);
        ogprice = (TextView)findViewById(R.id.textitemogpri);
        peroff = (TextView)findViewById(R.id.textitemperof);
        desc = (TextView)findViewById(R.id.textitemdesc);
        discprice = (TextView)findViewById(R.id.textitemdisprice);
        cartvalue = (TextView)findViewById(R.id.integer_number);
        cart = (FloatingActionButton)findViewById(R.id.addtocart);
        itemima = (ImageView)findViewById(R.id.itemimage);
        cartitem = (ImageView)findViewById(R.id.cartitemdetails);
        srch=findViewById(R.id.itmsearchpro);
        prooverview=findViewById(R.id.itoverview);
        prodingredients=findViewById(R.id.itdingredients);
        prodosage=findViewById(R.id.itdosage);
        prolife=findViewById(R.id.itlife);
        pronetquantity=findViewById(R.id.itnetquantity);
        probrandabout=findViewById(R.id.itbrandabout);
        procaution=findViewById(R.id.itcaution);
        proinfo=findViewById(R.id.itinfo);
        procertification=findViewById(R.id.itcertification);
        prid = findViewById(R.id.prodet);
        //line cutoff
        ogprice.setBackgroundResource(R.drawable.strikeline);
        //getting the item details from the dataabse
        getproductdetails(productid);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        dref = FirebaseDatabase.getInstance().getReference();
        //count
        crtcount();
        //on click
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if the user is login or not
                if (fuser != null) {
                    //if it is then add the particular item to cart for that user
                    dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener(){
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.child("Address").exists()) {
                                int ct = (int) dataSnapshot.child("Cart List").
                                        child("product").getChildrenCount();
                                if(ct < 8)
                                {
                                    addingtocart();

                                }
                                else {
                                    // custom dialog
                                    dialog = new Dialog(itemsdetails.this);
                                    dialog.setContentView(R.layout.homeaddressdialoge);
                                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                    // set the custom dialog components - text, image and button
                                    TextView tx = dialog.findViewById(R.id.textshowerror);
                                    tx.setText("Cannot Add More than 8 Items in Cart !!");
                                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                    lp.copyFrom(dialog.getWindow().getAttributes());
                                    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                    lp.gravity = Gravity.CENTER;
                                    dialog.getWindow().setAttributes(lp);
                                    dialog.show();
                                }
                            }
                            else
                            {
                                // custom dialog
                                dialog = new Dialog(itemsdetails.this);
                                dialog.setContentView(R.layout.useritemaddressdialoge);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                // set the custom dialog components - text, image and button
                                TextView tx = dialog.findViewById(R.id.textshowerror);
                                TextView add = dialog.findViewById(R.id.addaddressbtn);
                                tx.setText("Please Add Address !!");
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialog.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                lp.gravity = Gravity.CENTER;
                                dialog.getWindow().setAttributes(lp);
                                add.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent in = new Intent(itemsdetails.this,address.class);
                                        startActivity(in);
                                        dialog.dismiss();
                                    }
                                });
                                dialog.show();
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
                else {
                    toast=Toast.makeText(getApplicationContext(),"Login Please!!, We Insist!!",Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
        cartitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if the user is login or not
                if (fuser != null) {
                    Intent in = new Intent(getApplicationContext(),cart.class);
                    startActivity(in);
                    finish();
                }
                else {
                    toast=Toast.makeText(getApplicationContext(),"Login Please!!, We Insist!!",Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
        srch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(itemsdetails.this, search.class);
                startActivityForResult(in,1);
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_CANCELED) {
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        }
    }
    private void crtcount() {
        if (fuser != null) {
            dref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                child("product").getChildren()) {
                            String crtitm = ds.getKey().toString();
                            match.add(crtitm);
                        }
                    }
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        if (match.size()>0) {
                            cntcrt.setText(String.valueOf(match.size()));
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    //adding the value to cart
    private void addingtocart() {
        //getting the current date and time
        final String currenttime, currentdate;
        Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat currdate= new SimpleDateFormat("dd:MMM:yyyy");
        currentdate = currdate.format(calfordate.getTime());
        SimpleDateFormat currtime= new SimpleDateFormat("HH:MM:SS:a");
        currenttime = currtime.format(calfordate.getTime());
        //putting the cart info in the database
        final HashMap<String , Object> promap = new HashMap<>();
        promap.put("pid",productid);
        promap.put("disprice",dpri);
        promap.put("proname",name.getText().toString());
        promap.put("date",currentdate);
        promap.put("time",currenttime);
        promap.put("quantity",cartvalue.getText().toString());
        promap.put("image",img);
        promap.put("category",it);
        promap.put("ogprice",opri);
        //adding the cart detail to admin and the user
        dref.child("User").child(fuser.getUid()).child("Cart List").
                child("product").child(productid).updateChildren(promap);
        toast=Toast.makeText(getApplicationContext(),"Added To Cart\nClick on above Cart button, go to Cart",Toast.LENGTH_SHORT);
        toast();
        Intent intent = getIntent();
        finish();
        overridePendingTransition(0, 0);
        startActivity(intent);
        overridePendingTransition(0, 0);
            }
    //getting the details from database
    private void getproductdetails(String productid) {
        DatabaseReference proref = FirebaseDatabase.getInstance().getReference().child("products");
        proref.child(it).child(productid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    final products pro = dataSnapshot.getValue(products.class);
                    name.setText(pro.getProname());
                    prid.setText(pro.getProname());
                    desc.setText(pro.getDescription());
                    discprice.setText(pro.getDisprice() + " Rs/-");
                    Picasso.get().load(pro.getImage()).into(itemima);
                    img = pro.getImage();
                    prooverview.setText("OverView\n"+pro.getProoverview());
                    prodingredients.setText("Ingredients\n"+pro.getProingredients());
                    prodosage.setText("Dosage\n"+pro.getProdosage());
                    prolife.setText("Product Life\n"+pro.getProlife());
                    pronetquantity.setText("Net Quantity\n"+pro.getPronetquantity());
                    probrandabout.setText("About Brand\n"+pro.getProbrandabout());
                    procaution.setText("Caution\n"+pro.getProcaution());
                    proinfo.setText("Product Infromation\n"+pro.getProinfo());
                    procertification.setText("Certification\n"+pro.getProcertification());
                    //on image click
                    itemima.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // custom dialog
                            dialog = new Dialog(itemsdetails.this);
                            dialog.setContentView(R.layout.itemsimagedet);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                            // set the custom dialog components - text, image and button
                            ImageView proim=dialog.findViewById(R.id.proimage);
                            Picasso.get().load(pro.getImage()).into(proim);
                            TextView proidc = dialog.findViewById(R.id.proid);
                            proidc.setText("Product ID "+pro.getPid());
                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                            lp.copyFrom(dialog.getWindow().getAttributes());
                            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                            lp.gravity = Gravity.CENTER;
                            dialog.getWindow().setAttributes(lp);
                            dialog.show();
                        }
                    });
                    //off calculation
                    double  pri = Integer.parseInt(pro.getDisprice());
                    double  off = Integer.parseInt(pro.getOgprice());
                    double  diff = off - pri ;
                    perof = (int) ((diff / off) * 100);
                    if(perof < 0)
                    {
                        perof = 0;
                    }
                    if(pro.getOgprice().equals("0"))
                    {
                        ogprice.setVisibility(View.GONE);
                        peroff.setVisibility(View.GONE);
                    }
                    else
                    {
                        peroff.setText(String.valueOf(perof)+"% OFF");
                        ogprice.setText(pro.getOgprice()+" Rs/-");
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    //the item count to insert in cart
    public void increaseInteger(View view) {
        if(minteger < 10) {
            minteger = minteger + 1;
            display(minteger);
        }else
        {
            minteger = 0;
        }
    }public void decreaseInteger(View view) {
        if(minteger > 0) {
            minteger = minteger - 1;
            display(minteger);
        }else
        {
            minteger = 0;
        }
    }
    private void display(int number) {
        TextView displayInteger = (TextView) findViewById(
                R.id.integer_number);
        displayInteger.setText("" + number);
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}