package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ordereddetailsviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView id,qt,nm,dpr,tot,opri;
    ImageView proim;
    public itemclicklistner itemordered;
    public ordereddetailsviewholder(@NonNull View itemView) {
        super(itemView);
        id = itemView.findViewById(R.id.proid);
        qt = itemView.findViewById(R.id.quantity);
        nm = itemView.findViewById(R.id.itname);
        dpr = itemView.findViewById(R.id.itdisprice);
        tot = itemView.findViewById(R.id.ittot);
        proim = itemView.findViewById(R.id.itimage);
        opri = itemView.findViewById(R.id.itogprice);
        opri.setBackgroundResource(R.drawable.strikeline);
    }
    @Override
    public void onClick(View v) {
    }
    public void setItemordered(itemclicklistner itemordered) {
        this.itemordered = itemordered;
    }
}