package com.example.myapplication;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class cartviewholder  extends RecyclerView.ViewHolder implements View.OnClickListener {
    //binding of cartitems.xml file
    public TextView itname,itdisprice,itquantity,itogprice;
    public ImageView itimage,deleitem,editem;
    //on clicking on the particular item move
    public itemclicklistner itemclk;

    public cartviewholder(@NonNull View itemView) {
        super(itemView);
        itname = (TextView)itemView.findViewById(R.id.pronamecart);
        itdisprice = (TextView)itemView.findViewById(R.id.prodisprice);
        itquantity = (TextView)itemView.findViewById(R.id.integer_numbercart);
        itimage = (ImageView) itemView.findViewById(R.id.proimgcart);
        deleitem = (ImageView)itemView.findViewById(R.id.deletecart);
        editem = (ImageView)itemView.findViewById(R.id.editcart);
        itogprice = (TextView) itemView.findViewById(R.id.proogprice);
        itogprice.setBackgroundResource(R.drawable.strikeline);
    }
    @Override
    public void onClick(View v) {
        itemclk.onClick(v,getAdapterPosition(),false);
    }
    public void setItemclk(itemclicklistner itemclk) {
        this.itemclk = itemclk;
    }
}
