package com.example.myapplication;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Application;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.FirestoreRegistrar;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

import javax.annotation.Nullable;

public class address extends AppCompatActivity {
//binding
    private Button addaddre;
    private ImageView imad;
//firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //Toast
    private Toast toast;
    //recycler for address
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
//    Get Address on start if it is in database
    @Override
    public  void onStart(){
        super.onStart();
        imad.setVisibility(View.GONE);
        //checking if address already is in database
        dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //if yes then show with the help of recycler view
                if(dataSnapshot.child("Address").exists()){
                    FirebaseRecyclerOptions<addressdata> optioncart = new FirebaseRecyclerOptions.Builder<addressdata>()
                            .setQuery(dref.child("User").child(fuser.getUid()).child("Address"), addressdata.class).build();
                    FirebaseRecyclerAdapter<addressdata, addressviewholder> adapter = new
                            FirebaseRecyclerAdapter<addressdata, addressviewholder>(optioncart) {
                                @Override
                                protected void onBindViewHolder(@NonNull final addressviewholder addressviewholder,
                                                                int i, @NonNull
                                                                final addressdata addressdata) {
                                    //getting value from database
                                    addressviewholder.streetad.setText("Address : "+addressdata.getStreet());
                                    addressviewholder.lm.setText("LandMarg : "+addressdata.getLandMarg());
                                    addressviewholder.sta.setText("State : "+addressdata.getState());
                                    addressviewholder.pc.setText("PinCode : "+addressdata.getPinCode());
                                    addressviewholder.cy.setText("City : "+addressdata.getCity());
                                    final String addressid = addressdata.getAddressid();
                                    addressviewholder.adedit.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent in = new Intent(address.this,editaddress.class);
                                            in.putExtra("addreddid",addressid);
                                            in.putExtra("address",addressdata.getStreet());
                                            in.putExtra("landmarg",addressdata.getLandMarg());
                                            in.putExtra("state",addressdata.getState());
                                            in.putExtra("pincode",addressdata.getPinCode());
                                            in.putExtra("city",addressdata.getCity());
                                            startActivity(in);
                                        }
                                    });
                                    addressviewholder.addel.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            dref.child("User").child(fuser.getUid()).child("Address").child(addressid).removeValue();
                                            //toast
                                            toast = Toast.makeText(getApplicationContext(),"Address Deleted!!", Toast.LENGTH_SHORT);
                                            toast();
                                            //refresh
                                            Intent intent = getIntent();
                                            finish();
                                            overridePendingTransition(0, 0);
                                            startActivity(intent);
                                            overridePendingTransition(0, 0);
                                        }
                                    });
                                }
                                @NonNull
                                @Override
                                public addressviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                    View view = LayoutInflater.from(parent.getContext()).inflate
                                            (R.layout.addressview, parent, false);
                                    addressviewholder holder = new addressviewholder(view);
                                    return holder;
                                }
                            };
                    //recycler setting
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }
                else
                {
                    imad.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        imad=findViewById(R.id.imadd);
        //Firestore
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        dref = FirebaseDatabase.getInstance().getReference();
        //recycler
         recyclerView = findViewById(R.id.recycleraddress);
         recyclerView.setHasFixedSize(true);
         layoutManager = new LinearLayoutManager(this);
         recyclerView.setLayoutManager(layoutManager);
        //Click Button
        addaddre=findViewById(R.id.addaddress);
        addaddre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), addaddress.class);
                startActivity(in);
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}