package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.auth.User;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class registeractivity extends AppCompatActivity {
    //binding
    EditText edemail,edpass,name,phone;
    String userID;
    //firebase
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference reff;
    //toast
    private Toast toast;
    //alert
    private AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeractivity);
        //binding
        edemail= (EditText)findViewById(R.id.text_email);
        edpass = (EditText)findViewById(R.id.edit_text_password);
        name = (EditText)findViewById(R.id.text_name);
        phone=(EditText)findViewById(R.id.phone_number);
        //firebase
        mAuth = FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        reff= database.getReference();
        TextView reg= (TextView)findViewById(R.id.text_view_register_signup);
        reg.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),loginactivity.class);
                startActivity(i);
                finish();
            }
        });
        Button btnsignup = (Button)findViewById(R.id.button_sign_up);
        btnsignup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                registeruser();
            }
        });
    }
    //hashpassword
    public byte[] getHash(String password) {
        MessageDigest digest=null;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        digest.reset();
        return digest.digest(password.getBytes());
    }
    static String bin2hex(byte[] data) {
        return String.format("%0" + (data.length*2) + "X", new BigInteger(1, data)).toLowerCase();
    }
    //register user validation
    private void registeruser() {
        final String email = edemail.getText().toString().trim();
        String password = edpass.getText().toString().trim();
        String salt=password+"f1nd1ngn3m0";
        final String hashpassword = bin2hex(getHash(salt));
        final String usname = name.getText().toString().trim();
        final String mobno=phone.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if(usname.isEmpty()){
            name.setError("Name Please..");
            name.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            edemail.setError("Email please..");
            edemail.requestFocus();
            return;
        } else {
            if (!email.matches(emailPattern)) {
                edemail.setError("Invalid Email");
                edemail.requestFocus();
                return;
            }}
        if (password.isEmpty()) {
            edpass.setError("Password please..");
            edpass.requestFocus();
            return;
        }
        if (password.length() < 6) {
            edpass.setError("More than 6");
            edpass.requestFocus();
            return;
        }
        if(mobno.isEmpty()){
            phone.setError("Mobile Number Please..");
            phone.requestFocus();
            return;
        }
        if(mobno.length() < 10){
            phone.setError("Enter Correct Moblie No..");
            phone.requestFocus();
            return;
        }
        //creating account in the database
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Register Account");
        dialog.setMessage("Hang On!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                alertDialog.dismiss();
                if(task.isSuccessful()){
                    FirebaseUser user = mAuth.getCurrentUser();
                    userID = user.getUid();
                    HashMap<String, String> map = new HashMap<>();
                    map.put("UserName", usname);
                    map.put("UserEmail", email);
                    map.put("Password", hashpassword);
                    map.put("PhoneNumber", mobno);
                    map.put("userid",userID);
                    reff.child("User").child(userID).child("Profile").setValue(map);
                    toast=Toast.makeText(getApplicationContext(),"Registration Successful!!",Toast.LENGTH_SHORT);
                    toast();
                    Intent in = new Intent(registeractivity.this, loginactivity.class);
                    in.addFlags(in.FLAG_ACTIVITY_CLEAR_TOP);
                    in.addFlags(in.FLAG_ACTIVITY_CLEAR_TASK);
                    in.addFlags(in.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(in);
                }
                /*else if(task.getException() instanceof FirebaseAuthUserCollisionException)
                {
                    toast=Toast.makeText(getApplicationContext(),"You R Already Registered",Toast.LENGTH_SHORT);
                    toast();
                }*/
                else{
                    toast=Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}