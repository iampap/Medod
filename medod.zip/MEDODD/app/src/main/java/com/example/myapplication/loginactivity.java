package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class loginactivity extends AppCompatActivity {
    //binding
    EditText edemail, edpass;
    TextView admin, nadmin, logintitle,forpas;
    private Button adminbtnsignin;
    //firebase
    private FirebaseAuth mAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference references;
    //alert
    private AlertDialog alertDialog;
    //Toast
    private Toast toast;
    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        nadmin.setVisibility(View.GONE);
        adminbtnsignin.setVisibility(View.GONE);
        updateUI(firebaseUser);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginactivity);
        //binding
        edemail = (EditText) findViewById(R.id.text_email_login);
        edpass = (EditText) findViewById(R.id.edit_text_password_login);
        admin = (TextView) findViewById(R.id.adminlogin);
        nadmin = (TextView) findViewById(R.id.notadmin);
        logintitle = (TextView) findViewById(R.id.login_title);
        forpas = findViewById(R.id.forgetpass);
        //firebase binding
        mAuth = FirebaseAuth.getInstance();
        firebaseUser = mAuth.getCurrentUser();
        //register activity
        final TextView reg = (TextView) findViewById(R.id.text_view_register);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), registeractivity.class);
                startActivity(i);
                finish();
            }
        });
        //user login button
        final Button userbtnsignin = (Button) findViewById(R.id.button_sign_in);
        userbtnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userlogin();
            }
        });
        //admin login
        adminbtnsignin = (Button) findViewById(R.id.button_sign_inadmin);
        adminbtnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Adminlogin();
            }
        });
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nadmin.setVisibility(View.VISIBLE);
                reg.setVisibility(View.GONE);
                logintitle.setText("Admin Login");
                admin.setVisibility(View.GONE);
                forpas.setVisibility(View.GONE);
                adminbtnsignin.setVisibility(View.VISIBLE);
                userbtnsignin.setVisibility(View.GONE);
            }
        });
        nadmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nadmin.setVisibility(View.GONE);
                reg.setVisibility(View.VISIBLE);
                forpas.setVisibility(View.VISIBLE);
                logintitle.setText("Account Login");
                admin.setVisibility(View.VISIBLE);
                adminbtnsignin.setVisibility(View.GONE);
                userbtnsignin.setVisibility(View.VISIBLE);
            }
        });
        forpas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), forgotpassword.class);
                startActivity(i);
                finish();
            }
        });
    }
    //user login validation
    private void userlogin() {
        final String email = edemail.getText().toString().trim();
        String password = edpass.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            edemail.setError("Email please..");
            edemail.requestFocus();
            return;
        } else {
            if (!email.matches(emailPattern)) {
                edemail.setError("Invalid please");
                edemail.requestFocus();
                return;
            }
        }
        if (password.isEmpty()) {
            edpass.setError("Password please..");
            edpass.requestFocus();
            return;
        }
        if (password.length() < 4) {
            edpass.setError("More than 4");
            edpass.requestFocus();
            return;
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Login");
        dialog.setMessage("Hang On!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                alertDialog.dismiss();
                if (task.isSuccessful()) {
                    Intent in = new Intent(loginactivity.this, BNA.class);
                    in.addFlags(in.FLAG_ACTIVITY_CLEAR_TOP);
                    in.addFlags(in.FLAG_ACTIVITY_CLEAR_TASK);
                    in.addFlags(in.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(in);
                } else {
                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    //onstart of activity check weather the user is login or not
    private void updateUI(FirebaseUser user) {
        if (user != null) {
            Intent in = new Intent(loginactivity.this, BNA.class);
            startActivity(in);
            finish();
        }
    }
    //admin login
    public void Adminlogin() {

        final String email = edemail.getText().toString().trim();
        final String password = edpass.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            edemail.setError("Email please..");
            edemail.requestFocus();
            return;
        } else {
            if (!email.matches(emailPattern)) {
                edemail.setError("Invalid Email");
                edemail.requestFocus();
                return;
            }
        }
        if (password.isEmpty()) {
            edpass.setError("Password please..");
            edpass.requestFocus();
            return;
        }
        if (password.length() < 4) {
            edpass.setError("More than 4");
            edpass.requestFocus();
            return;
        }
        references = FirebaseDatabase.getInstance().getReference();
        references.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String eml = dataSnapshot.child("Admin").child("Email").getValue().toString();
                    String pass = dataSnapshot.child("Admin").child("password").getValue().toString();
                    if (eml.equals(email) && pass.equals(password)) {
                        toast=Toast.makeText(getApplicationContext(), "Loged In.", Toast.LENGTH_LONG);
                        toast();
                        Intent in = new Intent(loginactivity.this, AdminHome.class);
                        in.addFlags(in.FLAG_ACTIVITY_CLEAR_TOP);
                        in.addFlags(in.FLAG_ACTIVITY_CLEAR_TASK);
                        in.addFlags(in.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(in);
                    } else {
                        toast=Toast.makeText(getApplicationContext(), "Wrong Credencials..", Toast.LENGTH_SHORT);
                        toast();
                    }
                }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}