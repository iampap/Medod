package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/*when an activity is made for extracting multiple data from the database(multiple data of similar layout)then we create total
five (Three class and two xml file) the two file is created firstly when an empty activity is made and then create two class and an xml file
here the class is named as cartviewholder and cartdata and the xml file is cartitems file, the file to display the design of a
particular item. Now the cartviewholder is created to binding the details of the cartitems xml file in which the cartviewholder contain
binding of the textview and the imageview, etc in the xml file and which also extends the recyclerview and the cart data contain the string
items(Constructor , getter & setter) of database that are to be extracted form the database. The main empty activity contain the recycler
view to show the data*/
public class cart extends AppCompatActivity {
    //view for display the data from the user database
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //binding
    private TextView total,totcsb,tott,emy,bcnm,crtitmct;
    private Button next;
    private ImageView cart,back;
    private Integer totaldisamt = 0,totaldisprice=0,totalogprice = 0, totalogamt = 0,csb=0;
    //firebse
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //dialog
    private Dialog dialog;
    //Toast
    private Toast toast;
    private ArrayList<String> cartitems = new ArrayList<String>();
    //to display the data on starting of the activity
    @Override
    protected void onStart() {
        super.onStart();
        //checking in the database in user table that if the cart list exist
        dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                //check if exist
                if (dataSnapshot.child("Cart List").exists()) {
                    //yes then set query to database to retrive the data to display to cart page
                    FirebaseRecyclerOptions<cartdata> optioncart = new FirebaseRecyclerOptions.Builder<cartdata>()
                            .setQuery(dref.child("User").child(fuser.getUid()).child("Cart List").
                                    child("product"), cartdata.class).build();
                    FirebaseRecyclerAdapter<cartdata, cartviewholder> adapter = new FirebaseRecyclerAdapter<cartdata, cartviewholder>(optioncart) {
                        //in binding the data is loaded from data
                        @Override
                        protected void onBindViewHolder(@NonNull cartviewholder cartviewholder, int i, @NonNull final cartdata cartdata) {
                            //retriving the data
                            cartviewholder.itname.setText(cartdata.getProname());
                            cartviewholder.itdisprice.setText(cartdata.getDisprice() + " Rs /-");
                            cartviewholder.itquantity.setText("Quantity: " + cartdata.getQuantity());
                            Picasso.get().load(cartdata.getImage()).into(cartviewholder.itimage);
                            //total dis based on items
                            totaldisprice = Integer.parseInt(cartdata.getDisprice()) * Integer.parseInt(cartdata.getQuantity());
                            total();
                            if(cartdata.getOgprice().equals("0"))
                            {
                                cartviewholder.itogprice.setVisibility(View.GONE);
                            //cartdata.txtofpercent.setVisibility(View.GONE);
                                //total og in cart
                                totalogprice = Integer.parseInt(cartdata.getDisprice()) * Integer.parseInt(cartdata.getQuantity());
                                totalog();
                            }
                            else
                            {
                                double  pri = Integer.parseInt(cartdata.getDisprice());
                                double  off = Integer.parseInt(cartdata.getOgprice());
                                double  diff = off - pri ;
                                int  perof = (int) ((diff / off) * 100);
//                                placeholder.txtofpercent.setText(String.valueOf(perof)+"% OFF");
                                cartviewholder.itogprice.setText(cartdata.getOgprice()+" Rs/-");
                                //total og in cart
                                totalogprice = Integer.parseInt(cartdata.getOgprice()) * Integer.parseInt(cartdata.getQuantity());
                                totalog();
                            }
                            //item delete in cart
                            cartviewholder.deleitem.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dref.child("User").child(fuser.getUid()).child("Cart List").
                                            child("product").child(cartdata.getPid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Intent intent = getIntent();
                                                finish();
                                                overridePendingTransition(0, 0);
                                                startActivity(intent);
                                                overridePendingTransition(0, 0);
                                            }
                                        }
                                    });
                                }
                            });
                            //item edit in cart
                            cartviewholder.editem.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(getApplicationContext(), itemsdetails.class);
                                    in.putExtra("pid", cartdata.getPid());
                                    in.putExtra("category", cartdata.getCategory());
                                    in.putExtra("disprice",cartdata.getDisprice());
                                    in.putExtra("ogpri",cartdata.getOgprice());
                                    startActivity(in);
                                    finish();
                                }
                            });
                            cartviewholder.itimage.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(getApplicationContext(), itemsdetails.class);
                                    in.putExtra("pid", cartdata.getPid());
                                    in.putExtra("category", cartdata.getCategory());
                                    in.putExtra("disprice",cartdata.getDisprice());
                                    in.putExtra("ogpri",cartdata.getOgprice());
                                    startActivity(in);
                                    finish();
                                }
                            });
                        }
                        //in create view the loaded data is been showed in the xml file
                        @NonNull
                        @Override
                        public cartviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cartitems, parent, false);
                            cartviewholder holder = new cartviewholder(view);
                            return holder;
                        }
                    };
                    //calling the recycler view to show the data from the xml file to the cart activity xml page
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }
                //if the cart is empty the show the toast
                else {
                    total.setVisibility(View.GONE);
                    tott.setVisibility(tott.GONE);
                    emy.setVisibility(emy.VISIBLE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void totalog() {
        totalogamt = totalogamt + totalogprice;
        csb = totalogamt - totaldisamt;
        totcsb.setText(csb +" Rs /-");
    }
    private void total() {
        totaldisamt = totaldisamt + totaldisprice;
        total.setText("Total : " + totaldisamt.toString() + " Rs /-");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
    //setting the recycler view to display the data in the xml file
        recyclerView = findViewById(R.id.cartrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        dref = FirebaseDatabase.getInstance().getReference();
        //button for items ron edit and delete in the database
        total = (TextView)findViewById(R.id.itemtotal);
        crtitmct=findViewById(R.id.crtitemcount);
        totcsb = (TextView)findViewById(R.id.totcsbcart);
        next = (Button)findViewById(R.id.nextbutton);
        cart = (ImageView)findViewById(R.id.cart1);
        tott = findViewById(R.id.tottx);
        emy = findViewById(R.id.empty);
        back = findViewById(R.id.backim);
        bcnm = findViewById(R.id.name);
        emy.setVisibility(emy.GONE);
        //on clicking on the cart and the next(proceed) button
        /*cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toast=Toast.makeText(getApplicationContext(),"Already in Cart",Toast.LENGTH_LONG);
                toast();
            }
        });*/
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
            }
        });
        bcnm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED, returnIntent);
                finish();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //checking that if the item exist in the database
                        if (dataSnapshot.child("Cart List").exists()) {
                            if (dataSnapshot.child("Address").exists()) {
                            if (MySingletonClass.getInstance().getValue().equals("1")) {
                                //if yes then proceed with the intent of total price
                                Intent in = new Intent(getApplicationContext(), placeorder.class);
                                in.putExtra("total price", totaldisamt.toString());
                                in.putExtra("cashback", csb.toString());
                                startActivity(in);
                                finish();
                            } else {
                                dialog = new Dialog(cart.this);
                                dialog.setContentView(R.layout.homeaddressdialoge);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                // set the custom dialog components - text, image and button
                                TextView tx = dialog.findViewById(R.id.textshowerror);
                                tx.setText("Please go to Home Page & Check PinCode Delivery Status!!");
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialog.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                lp.gravity = Gravity.CENTER;
                                dialog.show();
                            }
                        }
                            else
                            {
                                // custom dialog
                                dialog = new Dialog(cart.this);
                                dialog.setContentView(R.layout.useritemaddressdialoge);
                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                // set the custom dialog components - text, image and button
                                TextView tx = dialog.findViewById(R.id.textshowerror);
                                TextView add = dialog.findViewById(R.id.addaddressbtn);
                                tx.setText("Please Add Address !!");
                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                lp.copyFrom(dialog.getWindow().getAttributes());
                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                lp.gravity = Gravity.CENTER;
                                dialog.getWindow().setAttributes(lp);
                                add.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent in = new Intent(cart.this,address.class);
                                        startActivity(in);
                                        dialog.dismiss();
                                        finish();
                                    }
                                });
                                dialog.show();
                            }
                        } else {
                            //if the data is not present in the database then show the toast
                            toast=Toast.makeText(getApplicationContext(), "Plz Add Something to Cart!!", Toast.LENGTH_SHORT);
                            toast();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        crtcount();
    }

    private void crtcount() {
        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (fuser != null) {
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                child("product").getChildren()) {
                            String crtitm = ds.getKey().toString();
                            cartitems.add(crtitm);
                        }
                    }
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        if (cartitems.size()>0) {
                            crtitmct.setText(String.valueOf(cartitems.size()));
                        }
                    }}
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}