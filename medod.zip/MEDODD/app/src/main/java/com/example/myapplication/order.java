package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.github.ybq.android.spinkit.style.ThreeBounce;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;


public class order extends Fragment {
    //binding
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private ImageView im1,im2,crt,srch;
    private DatabaseReference fs;
    private TextView itmcnt;
    //Toast
    private Toast toast;
    //dialog
    private Dialog dialog,loaderdialog;
    //loader
    private ThreeBounce mCircleDrawable;
    private ArrayList<String> cartitems = new ArrayList<String>();
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order, null);
        //recycler view
        recyclerView = view.findViewById(R.id.oredrrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        fs = FirebaseDatabase.getInstance().getReference();
        //images
        im1 = (ImageView)view.findViewById(R.id.go);
        im2 = (ImageView)view.findViewById(R.id.go1);
        crt=view.findViewById(R.id.cart);
        srch=view.findViewById(R.id.searchpro);
        itmcnt=view.findViewById(R.id.critemcount);
        //loader
        loader();
        //cart
        cartitm();
        //onclick
        srch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getContext(), search.class);
                startActivityForResult(in,1);
            }
        });
        crt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fuser != null) {
                    Intent in = new Intent(getContext(), cart.class);
                    startActivityForResult(in,1);
                } else {
                    toast = Toast.makeText(getContext(), "Login Please!!, We Insist!!", Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
        return view;
    }
    private void loader() {
        loaderdialog = new Dialog(getContext());
        loaderdialog.setCanceledOnTouchOutside(false);
        loaderdialog.setCancelable(false);
        loaderdialog.setContentView(R.layout.homeaddressdialoge);
        loaderdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView tx = loaderdialog.findViewById(R.id.textshowerror);
        LinearLayout ll=loaderdialog.findViewById(R.id.loaderll);
        ll.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        mCircleDrawable = new ThreeBounce();
        mCircleDrawable.setBounds(0, 0, 100, 100);
        mCircleDrawable.setColor(Color.parseColor("#ffffff"));
        tx.setCompoundDrawables(null, null, mCircleDrawable, null);
        mCircleDrawable.start();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(loaderdialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        loaderdialog.show();
    }
    //cartcount
    private void cartitm() {
        if (fuser != null) {
            fs.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                child("product").getChildren()) {
                            String crtitm = ds.getKey().toString();
                            cartitems.add(crtitm);
                        }
                    }
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        if (cartitems.size()>0) {
                            itmcnt.setText(String.valueOf(cartitems.size()));
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
    //on load of page
    @Override
    public void onStart() {
        super.onStart();
        fuser = mauth.getCurrentUser();
        //if user is login
        if (fuser != null) {
            im1.setVisibility(View.GONE);
            im2.setVisibility(View.GONE);
            //load from database
            final DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
            dref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //order table exist if
                    if (dataSnapshot.child("Orders").exists()) {
                        FirebaseRecyclerOptions<ordereddata> optioncart = new FirebaseRecyclerOptions.Builder<ordereddata>()
                            .setQuery(dref.child("User").child(fuser.getUid()).child("Orders"), ordereddata.class).build();
                    FirebaseRecyclerAdapter<ordereddata, orderedviewholder> adapter = new
                            FirebaseRecyclerAdapter<ordereddata, orderedviewholder>(optioncart) {
                                @Override
                                protected void onBindViewHolder(@NonNull final orderedviewholder orderedviewholder,
                                                                int i, @NonNull
                                                                final ordereddata ordereddata) {
                                    //getting value from database
                                    orderedviewholder.tot.setText("Total Price : " +ordereddata.getTotalPrice()+ " Rs /-");
                                    orderedviewholder.id.setText("Order Id : " +ordereddata.getOrderid() );
                                    orderedviewholder.tida.setText(ordereddata.getOrdertime() + ordereddata.getOrderdate());
                                    orderedviewholder.deldt.setText("Delivered By : " +ordereddata.getDeliveryDate());
                                    loaderdialog.dismiss();
                                    mCircleDrawable.stop();
                                    //getting ordeiid
                                    final String id;
                                    id=ordereddata.getOrderid();
                                    //order cancel button
                                    orderedviewholder.can.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            dref.child("User").child(fuser.getUid()).child("Orders").
                                                    child(id)
                                                    .removeValue();
                                            dref.child("Orders").child(fuser.getUid()).
                                                    child(id).removeValue();
                                            // Reload current fragment
                                            FragmentTransaction ft = getFragmentManager().beginTransaction();
                                            ft.replace(R.id.nav_host_fragment,new order()).remove(order.this);
                                            ft.commit();
                                            //toast
                                            toast = Toast.makeText(getContext(),"Product Canceled!!", Toast.LENGTH_SHORT);
                                            toast();
                                        }
                                    });
                                    //sending the ordeiid to next activity
                                    orderedviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent in = new Intent(getContext(), ordereddetails.class);
                                            in.putExtra("orderid", id);
                                            in.putExtra("Addreid",ordereddata.getAddressid());
                                            in.putExtra("total",ordereddata.getTotalPrice().toString());
                                            in.putExtra("orderdate",ordereddata.getOrderdate());
                                            in.putExtra("diledate",ordereddata.getDeliveryDate());
                                            in.putExtra("address",ordereddata.getStreet());
                                            in.putExtra("landmarg",ordereddata.getLandMarg());
                                            in.putExtra("state",ordereddata.getState());
                                            in.putExtra("pincode",ordereddata.getPinCode());
                                            in.putExtra("city",ordereddata.getCity());
                                            in.putExtra("Ordertime",ordereddata.getOrdertime());
                                            in.putExtra("Shipping",ordereddata.getShipping());
                                            in.putExtra("Cashback",ordereddata.getCashback());
                                            in.putExtra("orderstatus",ordereddata.getOrderstatus());
                                            in.putExtra("paymentmode",ordereddata.getPaymentmode());
                                            startActivity(in);
                                        }
                                    });
                                }
                                @NonNull
                                @Override
                                public orderedviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                    View view = LayoutInflater.from(parent.getContext()).inflate
                                            (R.layout.ordereditem, parent, false);
                                    orderedviewholder holder = new orderedviewholder(view);
                                    return holder;
                                }
                            };
                    //recycler setting
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }
                    else {
                        im2.setVisibility(View.VISIBLE);
                        im1.setVisibility(View.GONE);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
                }
            });
        }
        else{
            toast = Toast.makeText(getContext(),"Please Login!!, To view your Orders!!", Toast.LENGTH_SHORT);
            toast();
            im1.setVisibility(View.VISIBLE);
            im2.setVisibility(View.GONE);
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}