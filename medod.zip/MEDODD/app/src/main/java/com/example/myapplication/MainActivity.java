package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
        //splash screen time
        private static int SPLASH_SCREEN_TIME_OUT=1000;
        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                //checking the version
                if(Build.VERSION.SDK_INT >= 21)
                        //setting the window fullscreen and status bar null
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION,
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
                //which xml file to layout on splash screen for that time
                setContentView(R.layout.activity_main);
                new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() { Intent i=new Intent(MainActivity.this, BNA.class);
                                startActivity(i);
                                finish();
                        };
                }, SPLASH_SCREEN_TIME_OUT);
        }
}