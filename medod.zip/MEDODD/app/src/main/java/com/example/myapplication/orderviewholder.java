package com.example.myapplication;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class orderviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView itname,itdisprice,itquantity,itogprice,itoffper,ittot;
    public ImageView itimage;
    public itemclicklistner itemclk;
    public orderviewholder(@NonNull View itemView) {
        super(itemView);
        itname = (TextView)itemView.findViewById(R.id.pronamecart);
        itdisprice = (TextView)itemView.findViewById(R.id.prodispricecart);
        itquantity = (TextView)itemView.findViewById(R.id.integer_numbercart);
        itogprice = (TextView)itemView.findViewById(R.id.proogpricecart);
        itoffper = (TextView)itemView.findViewById(R.id.proofpercart);
        ittot = (TextView)itemView.findViewById(R.id.prototal);
        itimage = (ImageView) itemView.findViewById(R.id.proimgcart);
        itogprice.setBackgroundResource(R.drawable.strikeline);
    }
    @Override
    public void onClick(View v) {
        itemclk.onClick(v,getAdapterPosition(),false);
    }
    public void setItemclk(itemclicklistner itemclk) {
        this.itemclk = itemclk;
    }
}
