package com.example.myapplication;

public class cartdata {
    //string for values extracted from database
    private String proname,disprice,image,category,pid,quantity,ogprice;
    //default constructor
    public cartdata() {
    }
    //constructor
    public cartdata(String proname, String disprice, String image, String category, String pid, String quantity, String ogprice) {
        this.proname = proname;
        this.disprice = disprice;
        this.image = image;
        this.category = category;
        this.pid = pid;
        this.quantity = quantity;
        this.ogprice = ogprice;
    }
    //getter and setter
    public String getProname() {
        return proname;
    }
    public void setProname(String proname) {
        this.proname = proname;
    }
    public String getDisprice() {
        return disprice;
    }
    public void setDisprice(String disprice) {
        this.disprice = disprice;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getPid() {
        return pid;
    }
    public void setPid(String pid) {
        this.pid = pid;
    }
    public String getQuantity() {
        return quantity;
    }
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    public String getOgprice() {
        return ogprice;
    }
    public void setOgprice(String ogprice) {
        this.ogprice = ogprice;
    }
}