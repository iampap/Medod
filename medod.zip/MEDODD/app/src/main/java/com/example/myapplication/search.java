package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.github.ybq.android.spinkit.style.ThreeBounce;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class search extends AppCompatActivity {
    //binding
    private TextView npro;
    private EditText ser;
    private String srch;
    private ImageView s;
    //recycler
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    //firebase
    private DatabaseReference proref;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //dialog
    private Dialog dialog,loaderdialog;
    //toast
    private Toast toast,toat;
    //string
    private String categ,proid,src;
    //array
    private ArrayList<String> cartitems = new ArrayList<String>();
    private ArrayList<String> productitem = new ArrayList<String>();
    private ArrayList<String> match = new ArrayList<String>();
    //loader
    private ThreeBounce mCircleDrawable;
    //int
    Integer flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        //binding
        ser = findViewById(R.id.searchedtx);
        npro = findViewById(R.id.notpro);
        npro.setVisibility(View.GONE);
        s = findViewById(R.id.search);
        //firebase
        proref = FirebaseDatabase.getInstance().getReference();
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //recycler
        recyclerView = findViewById(R.id.searchrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //oncick
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                srch = ser.getText().toString().trim().toLowerCase();
                if(srch.isEmpty())
                {
                    ser.setError("Enter Product Name!!");
                    ser.requestFocus();
                    return;
                }
                else {
                    String[] searchsplit = srch.split(" ");
                    for (String sr : searchsplit) {
                            if (sr != null) {
                                src=sr;
                                flag = 0;
                                getdet();
                            }
                    }
                    loader();
                }
            }
        });
    }
    private void getdet() {
        proref.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String pico = ds.getKey().toString();
//                    prod.add(pico);
                    for (DataSnapshot ps : dataSnapshot.child(pico).getChildren()) {
                        String pro = ps.getKey().toString();
                        String des=ps.child("proname").getValue().toString().toLowerCase();
                        String[] numbers = des.split(" ");
                        for (String ss : numbers) {
                            if(src.equals(ss))
                            {
                                categ=pico;
                                proid=pro;
                                if(categ!=null){
                                    //checkitemincrt
                                    itemcart();
                                }
                                flag=0;
                                break;
                            }
                            else {
                                flag=1;
                            }
                        }
                    }
                }
                if(flag.equals(1)){
                    loaderdialog.dismiss();
                    mCircleDrawable.stop();
                    /*toat=Toast.makeText(getApplicationContext(),"Prdouct Not Found !!..",Toast.LENGTH_SHORT);
                    View view = toat.getView();
                    //Gets the actual oval background of the Toast then sets the colour filter
                    view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                    //Gets the TextView from the Toast so it can be editted
                    TextView text = view.findViewById(android.R.id.message);
                    text.setTextColor(Color.RED);
                    toat.show();*/
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_CANCELED) {
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        }
    }
    private void itemcart() {
        proref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("products").child(categ).exists()) {
                    for (DataSnapshot ds : dataSnapshot.child("products").child(categ).getChildren()) {
                        String pico = ds.getKey().toString();
                        productitem.add(pico);
                    }
                }
                if (fuser != null) {
                    if (dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").exists()) {
                        for (DataSnapshot ds : dataSnapshot.child("User").child(fuser.getUid()).child("Cart List").
                                child("product").getChildren()) {
                            String crtitm = ds.getKey().toString();
                            cartitems.add(crtitm);
                        }
                    }
                    for (int i = 0; i < productitem.size(); i++) {
                        for (int j = 0; j < cartitems.size(); j++) {
                            if (productitem.get(i).equals(cartitems.get(j))) {
                                match.add(cartitems.get(j));
                            }
                        }
                    }
                }
                if(productitem.size()>0){
                    getpro();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void getpro() {
                    FirebaseRecyclerOptions<products> options = new FirebaseRecyclerOptions.Builder<products>().setQuery
                            (proref.child("products").child(categ)/*child(String.valueOf(prod.get(i))).child(String.valueOf(itm.get(0))).
                                    orderByChild("proname").startAt(srch)*/, products.class).build();
                    FirebaseRecyclerAdapter<products, placeholder> adapter = new FirebaseRecyclerAdapter<products, placeholder>(options) {
                        @Override
                        protected void onBindViewHolder(@NonNull final placeholder placeholder, int i, @NonNull final products products) {
                            placeholder.txtproname.setText(products.getProname());
                            placeholder.textproprice.setText(products.getDisprice() + " Rs/-");
                            placeholder.textprodesc.setText(products.getDescription());
                            placeholder.chk.setVisibility(View.GONE);
                            placeholder.carttx.setVisibility(View.VISIBLE);
                            if(products.getOgprice().equals("0"))
                            {
                                placeholder.txtofprice.setVisibility(View.GONE);
                                placeholder.txtofpercent.setVisibility(View.GONE);
                            }
                            else
                            {
                                double  pri = Integer.parseInt(products.getDisprice());
                                double  off = Integer.parseInt(products.getOgprice());
                                double  diff = off - pri ;
                                int  perof = (int) ((diff / off) * 100);
                                placeholder.txtofpercent.setText(String.valueOf(perof)+"% OFF");
                                placeholder.txtofprice.setText(products.getOgprice()+" Rs/-");
                            }
                            Picasso.get().load(products.getImage()).into(placeholder.proimg);
                            loaderdialog.dismiss();
                            mCircleDrawable.stop();
                            for (int k=0;k<match.size();k++){
                                if(match.get(k).equals(products.getPid()))
                                {
                                    placeholder.chk.setVisibility(View.VISIBLE);
                                    placeholder.carttx.setVisibility(View.GONE);
                                }
                            }
                            String des=products.getProname().toLowerCase();
                            String[] numbers = des.split(" ");
                            for (String s : numbers) {
                                if (srch.equals(s)) {
                                    placeholder.itemView.getTop();
                                    placeholder.itemView.setBackgroundColor(Color.parseColor("#bdbdbd"));
                                }
                            }
                            //sending the intent to naxt activity
                            placeholder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    finish();
                                    Intent in = new Intent(search.this, itemsdetails.class);
                                    in.putExtra("pid", products.getPid());
                                    in.putExtra("category", categ);
                                    in.putExtra("disprice", products.getDisprice());
                                    in.putExtra("ogpri",products.getOgprice());
                                    startActivityForResult(in,1);
                                }
                            });
                            //adding to cart
                            placeholder.carttx.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (fuser != null) {
                                        proref.child("User").child(fuser.getUid()).addListenerForSingleValueEvent(new ValueEventListener(){
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                if(dataSnapshot.child("Address").exists())
                                                {
                                                    int ct = (int) dataSnapshot.child("Cart List").
                                                            child("product").getChildrenCount();
                                                    if(ct < 8)
                                                    {
                                                        //getting the current date and time
                                                        final String currenttime, currentdate;
                                                        Calendar calfordate = Calendar.getInstance();
                                                        SimpleDateFormat currdate= new SimpleDateFormat("dd:MMM:yyyy");
                                                        currentdate = currdate.format(calfordate.getTime());
                                                        SimpleDateFormat currtime= new SimpleDateFormat("HH:MM:SS:a");
                                                        currenttime = currtime.format(calfordate.getTime());
                                                        //putting the cart info in the database
                                                        final HashMap<String , Object> promap = new HashMap<>();
                                                        promap.put("pid",products.getPid());
                                                        promap.put("disprice",products.getDisprice());
                                                        promap.put("proname",products.getProname());
                                                        promap.put("date",currentdate);
                                                        promap.put("time",currenttime);
                                                        promap.put("quantity","1");
                                                        promap.put("image",products.getImage());
                                                        promap.put("category",srch);
                                                        promap.put("ogprice",products.getOgprice());
                                                        //adding the cart detail to admin and the user
                                                        proref.child("User").child(fuser.getUid()).child("Cart List").
                                                                child("product").child(products.getPid()).updateChildren(promap);
                                                        placeholder.chk.setVisibility(View.VISIBLE);
                                                        placeholder.carttx.setVisibility(View.GONE);
                                                    }
                                                    else {
                                                        // custom dialog
                                                        dialog = new Dialog(search.this);
                                                        dialog.setContentView(R.layout.homeaddressdialoge);
                                                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                        // set the custom dialog components - text, image and button
                                                        TextView tx = dialog.findViewById(R.id.textshowerror);
                                                        tx.setTextColor(Color.parseColor("#FF0000"));
                                                        tx.setText("Cannot Add More than 8 Items in Cart !!");
                                                        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                        lp.copyFrom(dialog.getWindow().getAttributes());
                                                        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                        lp.gravity = Gravity.CENTER;
                                                        dialog.show();
                                                    }
                                                }
                                                else
                                                {
                                                    // custom dialog
                                                    dialog = new Dialog(search.this);
                                                    dialog.setContentView(R.layout.useritemaddressdialoge);
                                                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                    // set the custom dialog components - text, image and button
                                                    TextView tx = dialog.findViewById(R.id.textshowerror);
                                                    TextView add = dialog.findViewById(R.id.addaddressbtn);
                                                    tx.setText("Please Add Address !!");
                                                    WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                    lp.copyFrom(dialog.getWindow().getAttributes());
                                                    lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                    lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                    lp.gravity = Gravity.CENTER;
                                                    dialog.getWindow().setAttributes(lp);
                                                    add.setOnClickListener(new View.OnClickListener() {
                                                        @Override
                                                        public void onClick(View v) {
                                                            Intent in = new Intent(search.this,address.class);
                                                            startActivity(in);
                                                            dialog.dismiss();
                                                        }
                                                    });
                                                    dialog.show();
                                                }
                                            }
                                            @Override
                                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                                    }
                                    else {
                                        toast=Toast.makeText(getApplicationContext(),"Login Please!!, We Insist!!",Toast.LENGTH_SHORT);
                                        toast();
                                    }
                                }
                            });
                        }
                        @NonNull
                        @Override
                        public placeholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.useritemproductlayout, parent, false);
                            placeholder holder = new placeholder(view);
                            return holder;
                        }
                    };
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
    }
    private void loader() {
        loaderdialog = new Dialog(search.this);
        loaderdialog.setCanceledOnTouchOutside(false);
        loaderdialog.setCancelable(false);
        loaderdialog.setContentView(R.layout.homeaddressdialoge);
        loaderdialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        TextView tx = loaderdialog.findViewById(R.id.textshowerror);
        LinearLayout ll=loaderdialog.findViewById(R.id.loaderll);
        ll.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        mCircleDrawable = new ThreeBounce();
        mCircleDrawable.setBounds(0, 0, 100, 100);
        mCircleDrawable.setColor(Color.parseColor("#ffffff"));
        tx.setCompoundDrawables(null, null, mCircleDrawable, null);
        mCircleDrawable.start();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(loaderdialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        loaderdialog.show();
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}